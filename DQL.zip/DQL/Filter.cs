﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class Filter
    {
        public int width;
        public int height;
        public List<Image_Data> filter_InputImages = new List<Image_Data>();
        public List<Image_Data> filter_OutputImages = new List<Image_Data>();
        public List<List<double>> weights = new List<List<double>>();
        Random rnd = new Random(Guid.NewGuid().GetHashCode());
        public Filter()
        {

        }


        public void RLU()
        {
            for (int i = 0; i < filter_InputImages.Count(); i++)
            {
                Image_Data image = new Image_Data();
                image.height = filter_InputImages[i].height;
                image.width = filter_InputImages[i].width;
                image.pixels.Clear();
                for (int y = 0; y < filter_InputImages[i].height; y++)
                {
                    List<double> pixels = new List<double>();
                    for (int x = 0; x < filter_InputImages[i].width; x++)
                    {
                        pixels.Add(TRANSFER(filter_InputImages[i].pixels[y][x]));
                        //                cout<<pixels.back()<<endl;
                    }
                    image.pixels.Add(pixels);
                }
                filter_OutputImages.Add(image);
            }
        }


        public void useFilter()
        {
            for (int e = 0; e < filter_InputImages.Count(); e++)
            {
                //neues Bild
                Image_Data result = new Image_Data();
                //selbe Maße
                result.height = filter_InputImages[e].height;
                result.width = filter_InputImages[e].width;
                //result.pixels.clear();
                

                for (int i = 0; i < filter_InputImages[e].height; i++)
                {
                    List<double> temp = new List<double>();
                    for (int a = 0; a < filter_InputImages[e].width; a++)
                    {
                        //DEBUG
                        //result.pixels[i][a]=compareFilter(e,i,a);
                        double tempe = compareFilter(e, a, i);

                        temp.Add(tempe);

                    }
                    result.pixels.Add(temp);
                }
                filter_OutputImages.Add(result);
                //        cout<<filter_OutputImages.size()<<endl;
            }
        }


        public double compareFilter(int e, int i, int a)
        {
            //e = ID
            //i = y
            //a = x

            Image_Data picture = filter_InputImages[e];


            double temp = 0;
            int topLeftCornery = 0;
            int topLeftCornerx = 0;

            int bottomRightCornery = 0;
            int bottomRightCornerx = 0;


            topLeftCornery = i - ((height - 1) / 2);
            topLeftCornerx = a - ((width - 1) / 2);


            bottomRightCornery = i + ((height - 1) / 2);
            bottomRightCornerx = a + ((width - 1) / 2);

            int filters = 0;

            int current_posx = topLeftCornerx;
            int current_posy = topLeftCornery;


            for (int x = 0; x < height; x++)
            {
                for (int y = 0; y < width; y++)
                {
                    if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                    {
                      //  temp += picture.pixels[current_posx + x][current_posy + y] * weights[x][y];
                        temp += picture.pixels[current_posy + y][current_posx + x] * weights[x][y];
                        filters++;

                    }
                }
            }

            return temp / filters;

        }
        public void downSample()
        {
            
            for (int e = 0; e < filter_InputImages.Count();e++ )
            {
                //neues Bild
                Image_Data result = new Image_Data();
                //selbe Maße
                result.height = (filter_InputImages[e].height / height) ;
                result.width = (filter_InputImages[e].width / width) ;
                //result.pixels.clear();
                

                for (int i = 0; i <= result.height; i++)
                {
                    List<double> temp = new List<double>();
                    for (int a = 0; a <= result.width;a++ )
                    {
                        //DEBUG
                        //result.pixels[i][a]=compareFilter(e,i,a);
                        double tempe = down(e, a, i);

                        temp.Add(tempe);
                        
                    }
                    result.pixels.Add(temp);
                    
                }
                filter_OutputImages.Add(result);
                //        cout<<filter_OutputImages.size()<<endl;

                
                
            }
        }



        public void pooling(int ID)
        {
            for (int e = 0; e < filter_InputImages.Count(); e++)
            {
                //neues Bild
                Image_Data result = new Image_Data();
                //selbe Maße
                result.height = (filter_InputImages[e].height - height) + 1;
                result.width = (filter_InputImages[e].width - width) + 1;
                //result.pixels.clear();

                for (int i = 0; i < result.height; i++)
                {
                    List<double> temp = new List<double>();
                    for (int a = 0; a < result.width; a++)
                    {
                        //DEBUG
                        //result.pixels[i][a]=compareFilter(e,i,a);
                        double tempe = pool(e, a, i, ID);

                        temp.Add(tempe);

                    }
                    result.pixels.Add(temp);
                }
                filter_OutputImages.Add(result);
                //        cout<<filter_OutputImages.size()<<endl;
            }
        }


        public double TRANSFER(double val)
        {
            if (val < 0)
                return 0;
            else
                return val;
        }

        public double down(int e,int a,int i)
        {
            Image_Data picture = filter_InputImages[e];
           
            double temp = 0;
            int topLeftCornery = 0;
            int topRightCornerx = 0;

            int current_posy = i;
            int current_posx = a;


            int filters = height * width;


            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                    {
                        // temp += picture.pixels[current_posx + x][current_posy + y];
                        temp += picture.pixels[current_posy + y][current_posx + x];
                        

                    }
                }

            }
            return temp/filters;
        }


        public double pool(int e, int a, int i, int ID)
        {
            Image_Data picture = filter_InputImages[e];
            double temp = 0;

            int topLeftCornery = 0;
            int topLeftCornerx = 0;

            int bottomRightCornery = 0;
            int bottomRightCornerx = 0;


            topLeftCornery = i - ((height - 1) / 2);
            topLeftCornerx = a - ((width - 1) / 2);


            bottomRightCornery = i + ((height - 1) / 2);
            bottomRightCornerx = a + ((width - 1) / 2);


            int current_posx = topLeftCornerx;
            int current_posy = topLeftCornery;

            int filters = 0;

            if (ID == 0)
            {            //average pooling

                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                        {
                           // temp += picture.pixels[current_posx + x][current_posy + y];
                            temp += picture.pixels[current_posy + y][current_posx + x];
                            filters++;

                        }
                    }
                }

                return temp / filters;
            }
            else if (ID == 1)
            {      //max pooling
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                        {
                            if (picture.pixels[current_posy + y][current_posx + x] > temp)
                            {
                                temp = picture.pixels[current_posy + y][current_posx + x];
                            }
                        }
                    }
                }
            }
            return temp;
        }


        public void getRandom(int heigh, int widt)
        {

            height = heigh;
            width = widt;
            

            weights.Clear();
            for (int i = 0; i < height; i++)
            {
                List<double> tempVector = new List<double>();
                for (int a = 0; a < width; a++)
                {
                    /* double temp;
                     temp = Program.random.NextDouble() * 2.0;
                     temp -= 0.5;*/

                    double rand = new double();
                    rand = (rnd.Next(0, 100000));
                    rand -= 50000.0;
                    double randn = rand / 50000.0;

                   
                    tempVector.Add(randn);
                }

                weights.Add(tempVector);

            }
        }
    }
}
