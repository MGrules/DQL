﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class FFLayer
    {
        public List<FFNeuron> neurons = new List<FFNeuron>();

        public FFLayer()
        {

        }
        public void freeMemory()
        {
            for (int i = 0; i < neurons.Count(); i++)
            {
                neurons[i].inputValues.Clear();
            }
        }


    }

}

