﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class Image_Data
    {
        public int height;
        public int width;
        public List<List<double>> pixels = new List<List<double>>();
        public Image_Data()
        {


        }
        public Image_Data(Bitmap bmp)
        {
            height = bmp.Height;
            width = bmp.Width;

            for(int y = 0; y < height; y++)
            {
                List<double> row = new List<double>();
                for(int x = 0; x < width ; x++)
                {
                    double value = ToGrayScale(bmp.GetPixel(x,y));
                    row.Add(value);
                }
                pixels.Add(row);
            }
        }
        public static double ToGrayScale(Color c)
        {
            double result = c.R + c.G + c.B;
            return result / (3*255);
        }
        public void showImage()
        {
            for (int i = 0; i < height; i++)
            {
                for (int a = 0; a < width; a++)
                {
                    Console.Write(pixels[i][a] + ";");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        
    }
}
