﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


namespace DQL
{
    class Program
    {

        public static Net convNet;
        public static Net FFNet;
        public static int NUMBER_OF_LAYERS_OFFSET = 2;
        public static int FIRST_LAYER_OFFSET = 4;
        
        public const int NUMBER_OF_LAYERS_IN_CONV_NET = 6;
        public const int NUMBER_OF_LAYERS_IN_FF_NET = 3;

        public static int[] NEURONS_PER_LAYER = new int[NUMBER_OF_LAYERS_IN_FF_NET]              { 4320, 4,2}; 

        public static int[] LAYER_ID = new int[NUMBER_OF_LAYERS_IN_CONV_NET]                      {  3, 1, 1, 1, 2,  0};//0=pool     1=conv  2=RLU   3=downsampling
        public static int[] POOLING_ID= new int[NUMBER_OF_LAYERS_IN_CONV_NET]                     {  0, 0, 0, 0, 0,  1};//0=average  1=max
        public static int[] FILTER_PER_LAYER = new int[NUMBER_OF_LAYERS_IN_CONV_NET]              {  1, 4, 3, 2, 1,  1};
        public static int[] DIMENSION_OF_FILTER_IN_LAYER_X= new int[NUMBER_OF_LAYERS_IN_CONV_NET] {  2, 2, 4, 2, 4, 21};   
        public static int[] DIMENSION_OF_FILTER_IN_LAYER_Y= new int[NUMBER_OF_LAYERS_IN_CONV_NET] {  2, 3, 4, 3, 4, 38 };

        
        /*
        public const int NUMBER_OF_LAYERS_IN_CONV_NET = 2;
        public const int NUMBER_OF_LAYERS_IN_FF_NET = 5;

        public static int[] NEURONS_PER_LAYER = new int[NUMBER_OF_LAYERS_IN_FF_NET] { 648, 2, 4, 3, 2 };

        public static int[] LAYER_ID = new int[NUMBER_OF_LAYERS_IN_CONV_NET] { 3,1 };//0=pool     1=conv  2=RLU   3=downsampling
        public static int[] POOLING_ID = new int[NUMBER_OF_LAYERS_IN_CONV_NET] { 0,0};//0=average  1=max
        public static int[] FILTER_PER_LAYER = new int[NUMBER_OF_LAYERS_IN_CONV_NET] { 1,1 };
        public static int[] DIMENSION_OF_FILTER_IN_LAYER_X = new int[NUMBER_OF_LAYERS_IN_CONV_NET] { 2,4 };
        public static int[] DIMENSION_OF_FILTER_IN_LAYER_Y = new int[NUMBER_OF_LAYERS_IN_CONV_NET] { 2,4 };

        */








        public static Random random = new Random();


        
        static void Main(string[] args)
        {
            NeuralNet();
            Interaction interaction = new Interaction();
            interaction.Interact();
        }

        static void NetToNet(Net C,Net F)
        {
            int numberOfInputsForNN=0;
            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count;i++) 
            {
                numberOfInputsForNN += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Count;
            }
            if (numberOfInputsForNN > Program.NEURONS_PER_LAYER[0])
            {
                Console.WriteLine();
                Console.Write("Warning: there are ");
                Console.Write(numberOfInputsForNN);
                Console.Write(" pictures to process but only ");
                Console.Write(Program.NEURONS_PER_LAYER[0]);
                Console.Write(" inputs in the FF! Do you want to go on? ");
                //Console.ReadLine();

            }


            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                for (int a = 0; a < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Count; a++)
                {
                    // C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].showImage();
                    if (C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count == 1 && C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count == 1)
                    {

                        F.inputValues.Add(C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0][0]);
                    }else if (C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Count != 0)
                    {
                        string error;
                        error = "ERROR: UNFITTING IMAGE!!! Image should 1x1 but it is ";
                        error += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count;
                        error += "x";
                        error += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count;
                        Console.WriteLine(error);
                    }
                    else
                    {
                        string error;
                        error = "ERROR: 0-DIMENSIONAL IMAGE!!!";
                        
                        Console.WriteLine(error);
                        throw new Exception();
                    }
                }
            }
            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_InputImages.Clear();
                C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Clear();
            }

        }




        static int NeuralNet()
        {

            convNet = new Net
            {
                filename = "D:\\Programme\\DQL\\exampleConv.nn",
                type = 0
            };
            convNet.generateStructure();
            convNet.CreateConvNet(false, convNet.structureVector);
            //convNet.Show();

            convNet.Save();

            FFNet = new Net
            {
                filename = "D:\\Programme\\DQL\\exampleFF.nn",
                type = 1
            };
            FFNet.generateStructure();
            FFNet.CreateFFNet(false,FFNet.structureVector);

            return 0;
        }
        public static void PassThrough()
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();

            Console.WriteLine("Conv");
            convNet.passThroughConv();
            Console.WriteLine("\tDone");
            NetToNet(convNet, FFNet);
            Console.WriteLine("FFNet");
            FFNet.passThroughFF();
            Console.WriteLine("\tDone");
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;

            Console.WriteLine(elapsedMs + " ms");
        }
    }
}
