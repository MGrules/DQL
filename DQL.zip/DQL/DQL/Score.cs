﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{

    class Score
    {
        public static Net Convscore = new Net();
        public static Net FFscore = new Net();

        public static int NUMBER_OF_LAYERS_IN_FF_NET = 3;
        public static int NUMBER_OF_LAYERS_IN_CONV_NET = 1;
        public static int[] NEURONS_PER_LAYER = new int[3] { 80, 10, 10 };
        public static object o = new object();

        public static List<int> LAYER_ID = new List<int> { 4 };//0=pool     1=conv  2=RLU   3=downsampling
        public static List<int> POOLING_ID = new List<int> { 0 };//0=average  1=max
        public static List<int> FILTER_PER_LAYER = new List<int> { 10 };
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_X = new List<int> { 34 };
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_Y = new List<int> { 41 };

        public static List<int> structureVector = new List<int> { 10 };


        public static void makeScoreNet()
        {
            Convscore.type = 0;

            makeConvNet();
            return;
        }

        public static int showResult()
        {
            List<double> results = new List<double>();



            for (int a = 0; a < FILTER_PER_LAYER[NUMBER_OF_LAYERS_IN_CONV_NET - 1]; a++)
            {
                results.Add(Convscore.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[a].filter_OutputImages[0].pixels[0][0]);
            }
            int indexMax = !results.Any() ? -1 : results.Select((value, index) => new { Value = value, Index = index }).Aggregate((a, b) => (a.Value > b.Value) ? a : b).Index;


            Console.WriteLine("MaxIndex: " + indexMax);
            Console.WriteLine();

            return indexMax;
        }

        public static void NetToNet(Net C, Net F)
        {
            int numberOfInputsForNN = 0;
            for (int i = 0; i < C.convLayer[Score.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                numberOfInputsForNN += C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length;
            }
            if (numberOfInputsForNN > NEURONS_PER_LAYER[0])
            {
                Console.WriteLine();
                Console.Write("Warning: there are ");
                Console.Write(numberOfInputsForNN);
                Console.Write(" pictures to process but only ");
                Console.Write(Score.NEURONS_PER_LAYER[0]);
                Console.Write(" inputs in the FF! Do you want to go on? ");
                //Console.ReadLine();

            }
            else if (numberOfInputsForNN < NEURONS_PER_LAYER[0])
            {
                Console.Write("Warning: there are ");
                Console.Write(numberOfInputsForNN);
                Console.Write(" pictures to process and ");
                Console.Write(NEURONS_PER_LAYER[0]);
                Console.Write(" inputs in the FF! Do you want to go on? ");
                //Console.ReadLine();
            }

            for (int i = 0; i < C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                for (int a = 0; a < C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length; a++)
                {
                    // C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].showImage();
                    if (C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a] == null)
                    {
                        continue;
                    }
                    if (C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count == 1 && C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count == 1)
                    {

                        F.inputValues.Add(C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0][0]);
                    }
                    else if (C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length != 0 && C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0] != null)
                    {
                        string error;
                        error = "ERROR: UNFITTING IMAGE!!! Image should 1x1 but it is ";
                        error += C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count;
                        error += "x";
                        error += C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count;
                        Console.WriteLine(error);
                    }
                    else
                    {
                        string error;
                        error = "ERROR: 0-DIMENSIONAL IMAGE!!!";

                        Console.WriteLine(error);
                        throw new Exception();
                    }
                }
            }
            for (int i = 0; i < C.convLayer[NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                //  C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_InputImages.Length();
                // C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length();
            }

        }



        public static List<Bitmap> TakeScreenshot()
        {


            Bitmap s1 = new Bitmap(25, 40);
            Bitmap s2 = new Bitmap(25, 40);

            Graphics g1 = Graphics.FromImage(s1);
            Graphics g2 = Graphics.FromImage(s2);


            g1.CopyFromScreen(229, 38, 0, 0, s1.Size);
            g2.CopyFromScreen(701, 38, 0, 0, s2.Size);

            for (int a = 0; a < s2.Width; a++)
            {
                for (int b = 0; b < s2.Height; b++)
                {
                    int val = (int)(255 * Image_Data.ToGrayScale(s2.GetPixel(a, b)));
                    s2.SetPixel(a, b, Color.FromArgb(0, val, val, val));
                }
            }

            for (int a = 0; a < s1.Width; a++)
            {
                for (int b = 0; b < s1.Height; b++)
                {
                    int val = (int)(255 * Image_Data.ToGrayScale(s1.GetPixel(a, b)));
                    s1.SetPixel(a, b, Color.FromArgb(1, val, val, val));
                }
            }


            //   g1.Dispose();
            //  g2.Dispose();
            /*
            for(int a = 0; a < screen.Height; a++)
            {
                for (int b = 0; b < screen.Width; b++)
                {
                    Color p = screen.GetPixel(b, a);
                    Console.Write("(" + p.R + "|" + p.G + "|" + p.B + ") , ");
                }
                Console.WriteLine();
            }
            */
            s1.Save("D:\\test.bmp", ImageFormat.Bmp);
            List<Bitmap> screens = new List<Bitmap>
            {
                s1,
                s2
            };
            
            return screens;
        }




        public static int[] getScore()
        {
            List<Bitmap> screenshots = TakeScreenshot();
            Image_Data test = new Image_Data(screenshots[0]);
            for (int i = 0; i < 10; i++)
            {
                Convscore.convLayer[0].filter[i].filter_InputImages[0] = test;
            }
            //Convscore.getImage(TakeScreenshot()[0]);
            passThroughConv();
            int p1 = HighestIndex();
            test = new Image_Data(screenshots[1]);
            for (int i = 0; i < 10; i++)
            {
                Convscore.convLayer[0].filter[i].filter_InputImages[0] = test;
            }
            //Convscore.getImage(TakeScreenshot()[0]);
            passThroughConv();
            int p2 = HighestIndex();
            Console.WriteLine(p1 + ":" + p2);
            return new int[2] { p1, p2 };
        }


        public static void makeConvNet()
        {
            for (int a = 0; a < structureVector.Count; a++)
            {

                ConvLayer tempLayer = new ConvLayer();


                for (int b = 0; b < structureVector[a]; b++)
                {
                    Filter tempFilter = new Filter(a);
                    tempFilter.weights.Clear();


                    if (LAYER_ID[a] == 1 || LAYER_ID[a] == 4)
                    {
                        string path = "D:\\Filter\\" + b + ".bmp";
                        tempFilter.loadFilter(DIMENSION_OF_FILTER_IN_LAYER_Y[a], DIMENSION_OF_FILTER_IN_LAYER_X[a], path);



                    }
                    else
                    {
                        tempFilter.height = DIMENSION_OF_FILTER_IN_LAYER_Y[a];
                        tempFilter.width = DIMENSION_OF_FILTER_IN_LAYER_X[a];
                    }



                    tempLayer.filter.Add(tempFilter);


                }
                Convscore.convLayer.Add(tempLayer);

            }


            Console.WriteLine("Done making new net ");
            return;
        }


        public static void makeFFNet()
        {
            for (int a = 0; a < NUMBER_OF_LAYERS_IN_FF_NET; a++)
            {

                FFLayer tempLayer = new FFLayer();

                tempLayer.neurons.Clear();
                for (int b = 0; b < NEURONS_PER_LAYER[a]; b++)
                {
                    FFNeuron tempNeuron = new FFNeuron();
                    if (a < NUMBER_OF_LAYERS_IN_FF_NET - 1)
                    {

                        tempNeuron.getRandom(NEURONS_PER_LAYER[a + 1]);


                        tempLayer.neurons.Add(tempNeuron);

                    }
                    else
                    {
                        tempNeuron.BIAS = 0;
                        tempLayer.neurons.Add(tempNeuron);
                    }


                }
                FFscore.FFLayer.Add(tempLayer);

            }



        }


        public void passThroughFF()
        {
            for (int i = 0; i < NUMBER_OF_LAYERS_IN_FF_NET; i++)
            {
                if (i == 0)
                {
                    for (int x = 0; x < FFscore.FFLayer[0].neurons.Count; x++)
                    {
                        for (int y = 0; y < FFscore.inputValues.Count; y++)
                        {
                            FFscore.FFLayer[0].neurons[x].outputValue += (FFscore.inputValues[y]);
                        }
                    }

                    for (int x = 0; x < FFscore.FFLayer[0].neurons.Count; x++)
                    {
                        FFscore.FFLayer[0].neurons[x].calculateSum();
                    }
                    continue;
                }





                for (int a = 0; a < NEURONS_PER_LAYER[i - 1]; a++)
                {

                    for (int b = 0; b < NEURONS_PER_LAYER[i]; b++)
                    {
                        if (i < NUMBER_OF_LAYERS_IN_FF_NET)
                        {
                            FFscore.FFLayer[i].neurons[b].outputValue += (FFscore.FFLayer[i - 1].neurons[a].weightsToNextNeurons[b] * FFscore.FFLayer[i - 1].neurons[a].outputValue);
                        }
                    }
                    Parallel.For(0, FFscore.FFLayer[i].neurons.Count, z =>
                    {
                        FFscore.FFLayer[i].neurons[z].calculateSum();
                    });


                    FFscore.FFLayer[i].freeMemory();
                }




            }

            for (int y = 0; y < NUMBER_OF_LAYERS_IN_FF_NET; y++)
            {

                FFscore.FFLayer[y].freeMemory();
            }

        }
        static int HighestIndex()
        {
            int index = 0;
            double highest = 0;

            for(int a = 0; a < Convscore.convLayer[Convscore.convLayer.Count - 1].filter.Count; a++)
            {
                Image_Data b = Convscore.convLayer[Convscore.convLayer.Count - 1].filter[a].filter_OutputImages[0];
                double v = b.pixels[0][0];

               if(v > highest)
                {
                    highest = v;
                    index = a;
                }
            }

            return index;
        }

        public static void passThroughConv()
        {
            Console.WriteLine("\t" + Convscore.inputImages.Count + "\t" + NUMBER_OF_LAYERS_IN_CONV_NET);
            for (int i = 0; i < NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                Console.WriteLine("Currently in Layer " + i + " of " + NUMBER_OF_LAYERS_IN_CONV_NET + " the conv; Layer ID = " + LAYER_ID[i]);

                //        cout<<"-----------------------------------------"<<endl
                if (i == 0)
                {

                    Parallel.For(0, FILTER_PER_LAYER[i], a =>
                    {
                        for (int b = 0; b < Convscore.inputImages.Count; b++)
                        {
                            lock (o)
                            {

                                Convscore.convLayer[i].filter[a].outputImagesNumber = Convscore.inputImages.Count;
                            }
                        }
                        switch (LAYER_ID[0])
                        {
                            case 0: Convscore.convLayer[i].filter[a].pooling(POOLING_ID[0]); break;
                            case 1: Convscore.convLayer[i].filter[a].useFilter(); break;
                            case 2: Convscore.convLayer[i].filter[a].RLU(); break;
                            case 3: Convscore.convLayer[i].filter[a].downSample(); break;
                            case 4: Convscore.convLayer[i].filter[a].singleFilter(); break;
                        }


                    });

                    Image_Data img = Convscore.convLayer[i].filter[0].filter_OutputImages[0];
                    Console.WriteLine(img.width + "_" + img.height);
                    Bitmap bmp = new Bitmap(img.width, img.height);
                    for (int a = 0; a < img.height; a++)
                    {
                        for (int b = 0; b < img.width; b++)
                        {
                            int val = img.pixels[a][b] == 0 ? 0 : (int)(255 * img.pixels[a][b]);
                            Color c;
                            try
                            {
                                c = Color.FromArgb(0, val, val, val);
                            }
                            catch (Exception e) { c = Color.FromArgb(0, 0, 0, 0); }

                            bmp.SetPixel(b, a, c);
                        }
                    }
                    //bmp.Save("D:/NewScreen.bmp", System.Drawing.Imaging.ImageFormat.Bmp);

                    Convscore.convLayer[i].freeMemory();


                    continue;

                }

                if (LAYER_ID[i] == 0)       //pooling
                {

                    for (int a = 0; a < FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, Convscore.convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    // convLayer[i].filter[a].filter_InputImages[c] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    Convscore.convLayer[i].filter[a].filter_InputImages[(Convscore.convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (Convscore.convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    Convscore.convLayer[i].filter[a].outputImagesNumber = Convscore.convLayer[i].filter[a].filter_OutputImages.Length;
                                }
                            });

                        }
                        //convLayer[i].filter[a].pooling(Program.POOLING_ID[i]);
                    };


                    Parallel.For(0, FILTER_PER_LAYER[i], a =>
                    {
                        Convscore.convLayer[i].filter[a].pooling(POOLING_ID[i]);
                    });
                    Convscore.convLayer[i].freeMemory();


                }
                else if (LAYER_ID[i] == 1)
                {
                    for (int a = 0; a < FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < FILTER_PER_LAYER[i - 1]; b++)
                        {

                            Parallel.For(0, Convscore.convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    Convscore.convLayer[i].filter[a].filter_InputImages[(Convscore.convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (Convscore.convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    Convscore.convLayer[i].filter[a].outputImagesNumber = Convscore.convLayer[i].filter[a].filter_OutputImages.Length;
                                }
                            });

                            // convLayer[i - 1].filter[b].filter_OutputImages.Clear();
                        }

                        //  convLayer[i].filter[a].useFilter();


                    }
                    Parallel.For(0, FILTER_PER_LAYER[i], a =>
                    {
                        Convscore.convLayer[i].filter[a].useFilter();

                    });

                    Parallel.For(0, FILTER_PER_LAYER[i - 1], a =>
                    {
                        Convscore.convLayer[i - 1].filter[a].outputImagesNumber = 0;
                    });

                    Convscore.convLayer[i].freeMemory();


                }
                else if (LAYER_ID[i] == 2)
                {

                    for (int a = 0; a < FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, Convscore.convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    Convscore.convLayer[i].filter[a].filter_InputImages[(Convscore.convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (Convscore.convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    Convscore.convLayer[i].filter[a].outputImagesNumber = Convscore.convLayer[i].filter[a].filter_OutputImages.Length;
                                }
                            });
                        }
                        //convLayer[i].filter[a].RLU();
                    };

                    Parallel.For(0, FILTER_PER_LAYER[i], a =>
                    {
                        Convscore.convLayer[i].filter[a].RLU();
                    });
                    Parallel.For(0, FILTER_PER_LAYER[i - 1], a =>
                    {
                        Convscore.convLayer[i - 1].filter[a].outputImagesNumber = 0;
                    });
                    Convscore.convLayer[i].freeMemory();

                }
                else if (LAYER_ID[i] == 3)
                {

                    for (int a = 0; a < FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, Convscore.convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    Convscore.convLayer[i].filter[a].filter_InputImages[(Convscore.convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (Convscore.convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    Convscore.convLayer[i].filter[a].outputImagesNumber = Convscore.convLayer[i].filter[a].filter_OutputImages.Length;
                                }
                            });
                        }

                        Convscore.convLayer[i].filter[a].downSample();
                    }
                    Convscore.convLayer[i].freeMemory();
                    Parallel.For(0, FILTER_PER_LAYER[i - 1], a =>
                    {
                        Convscore.convLayer[i].filter[a].outputImagesNumber = 0;
                    });
                }
            }
            for (int i = 0; i < NUMBER_OF_LAYERS_IN_CONV_NET - 1; i++)
            {
                for (int a = 0; a < FILTER_PER_LAYER[i]; a++)
                {
                    // convLayer[i].filter[a].filter_InputImages.Clear();
                    //convLayer[i].filter[a].filter_OutputImages.Clear();
                }
            }

        }
    }
}
