﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class Menu
    {
        public Menu()
        {
        }
        public void ShowMenu()
        {
            Console.WriteLine("0: Start\n" + "1: Load Net\n" + "2: Save Net\n" + "3: Ende");
        }
        public int GetInput()
        {
            return int.Parse(Console.ReadLine());
        }


    }
}
