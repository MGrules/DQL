﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class FFNeuron
    {
        public double error;
        public double outputValue=0.0;
        public double BIAS = 1;
     //   public List<double> inputValues = new List<double>();
        public List<double> weightsToNextNeurons = new List<double>();
        public int numberOfNextNeurons;
        Random rnd = new Random(Guid.NewGuid().GetHashCode());
        public FFNeuron()
        {

        }
        
        



        public void calculateSum()
        {
            
            outputValue = sigmoid(outputValue + BIAS);
        }

        public void getRandom(int nextNeurons)
        {
            numberOfNextNeurons = nextNeurons;
            for(int i = 0; i < numberOfNextNeurons; i++)
            {

                
                double rand = new double();
                rand=(rnd.Next(0,10000));
                rand -= 5000.0;
                double randn =  rand/ 5000.0 ;
                weightsToNextNeurons.Add(randn);
               
                

            }



        }

        double sigmoid(double input)
        {
            double e = 2.71828182846;
            double temp=0.0;
            temp = Math.Pow(e, -input);
            temp += 1.0;
            temp = 1.0 / temp;


            return temp;
        }

    }
}
