﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;

namespace DQL
{
    class Interaction
    {
        [DllImport("user32.dll")]
        public static extern bool MoveWindow(IntPtr hWnd, int x, int y, int Width, int Height, bool Repaint);
        [DllImport("user32.dll")]
        public static extern int SetForegroundWindow(IntPtr hWnd);

        private const int MOUSEEVENTF_MOVE = 0x0001; /* mouse move */
        private const int MOUSEEVENTF_LEFTDOWN = 0x0002; /* left button down */
        private const int MOUSEEVENTF_LEFTUP = 0x0004; /* left button up */
        private const int MOUSEEVENTF_RIGHTDOWN = 0x0008; /* right button down */

        [DllImport("user32.dll",
            CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons,
                                              int dwExtraInfo);
        public int[] lastScore;
        public List<Bitmap> last5 = new List<Bitmap>();
        public List<int> actions = new List<int>();

        void RegularClick()
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        }
        void RegularStartUp(Process process)
        {
            try
            {
                SetForegroundWindow(process.MainWindowHandle);
            }
            catch (Exception e) { }

            SendKeys.SendWait(" ");
        }

        Bitmap TakeScreenshot()
        {
            Bitmap screen = new Bitmap(950, 525);
            Graphics g = Graphics.FromImage(screen);
            g.CopyFromScreen(5, 75, 0, 0, screen.Size);
            for (int a = 0; a < screen.Width; a++)
            {
                for (int b = 0; b < screen.Height; b++)
                {
                    int val = (int)(255 * Image_Data.ToGrayScale(screen.GetPixel(a, b)));
                    screen.SetPixel(a, b, Color.FromArgb(1, val, val, val));
                }
            }
            screen.Save("D:/Screen.bmp", ImageFormat.Bmp);
            if (last5.Count < 500)
            {
                last5.Add(screen);
            }
            else
            {
                last5.RemoveAt(0);
                last5.Add(screen);
            }
            g.Dispose();
            /*
            for(int a = 0; a < screen.Height; a++)
            {
                for (int b = 0; b < screen.Width; b++)
                {
                    Color p = screen.GetPixel(b, a);
                    Console.Write("(" + p.R + "|" + p.G + "|" + p.B + ") , ");
                }
                Console.WriteLine();
            }
            */
            return screen;
        }
        public Interaction()
        {

        }
        [STAThread]
        public void Interact()
        {


            Process[] processes = Process.GetProcessesByName("Pong");

            if (processes.Length == 0) return;
            Process process = null;
            for (int a = 0; a < processes.Length; a++)
            {
                if (processes[a].MainWindowTitle.Contains("Pong"))
                {
                    process = processes[a];
                    break;
                }
            }
            RegularStartUp(process);
            SetForegroundWindow(process.MainWindowHandle);
            MoveWindow(process.MainWindowHandle, 0, 0, 960, 605, false);


            Stopwatch actionTimer = new Stopwatch();
            while (process != null)
            {
                SetForegroundWindow(process.MainWindowHandle);
                int[] newScore = Score.getScore();
                Program.convNet.getImage(TakeScreenshot());
                Program.PassThrough();
                int result = Program.FFNet.showResult();
                if (actions.Count < 500)
                {
                    actions.Add(result);
                }
                else
                {
                    actions.RemoveAt(0);
                    actions.Add(result);
                }
                
                if (result == 0)
                {
                    for (int i = 0; i < 150; i++)
                    {
                        SendKeys.SendWait("{DOWN}");
                        Console.WriteLine("DOWN");
                        Thread.Sleep(1);
                    }
                }
                else
                {
                    for (int i = 0; i < 150; i++)
                    {
                        SendKeys.SendWait("{UP}");
                        Console.WriteLine("UP");
                        Thread.Sleep(1);
                    }
                }

                Console.WriteLine(result);
                Thread.Sleep(5);
                for(int a = 0; a < newScore.Length; a++)
                {
                    Console.WriteLine(a + ": " + newScore[a]);
                }
                if(lastScore != null && (lastScore[0] != newScore[0] || lastScore[1] != newScore[1]))
                {
                    bool b = lastScore[1] != newScore[1];
                    Evaluate(b);
                }
                lastScore = newScore;

                processes = Process.GetProcessesByName("Pong");
                if (processes.Length == 0)
                    break;

                for (int a = 0; a < processes.Length; a++)
                {
                    if (processes[a].MainWindowTitle.Contains("Pong"))
                    {
                        process = processes[a];
                        break;
                    }
                }
                Program.FFNet.Save();
            }
        }
        public void Evaluate(bool we)
        {
            /*! ! MULTITHREADING ! !*/
            Console.WriteLine("Evaluate");

            SendKeys.SendWait("{ENTER}");


            for (int a = last5.Count - 1; a >= 0; a--)
            {
                Console.WriteLine("Conv");
                Program.convNet.passThroughConv(last5.GetRange(a, 1), true);
                Console.WriteLine("\tDone");
                Program.NetToNet(Program.convNet, Program.FFNet);
                Console.WriteLine("FFNet");
                Program.FFNet.passThroughFF();
                Console.WriteLine("\tDone");

                
                //exp: 1 bzw 0
                List<double> wanted = new List<double>();
                for(int b = 0; b < 2; b++)
                {
                    if(actions[a] == b)
                    {
                        wanted.Add(we == true ? 1 : 0);
                    }
                    else
                    {
                        wanted.Add(0.5);
                    }
                    wanted[wanted.Count - 1] *= Math.Pow(0.99, last5.Count - a);
                }
                List<double> FFError = Program.FFNet.backpassFF(wanted);
                FFError.RemoveRange(25, FFError.Count - 25);
                Program.convNet.backpassConv(FFError);
            }

            last5.Clear();
            actions.Clear();
            SendKeys.SendWait("{ESC}");
            Console.WriteLine("Click!");
        }
    }
}
