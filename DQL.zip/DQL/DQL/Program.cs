﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.IO;

namespace DQL
{
    class Program
    {
        public static double step = 0.1;
        public static List<double> m_wanted = new List<double>();

        public static string saveName = "Network1.header";
        public static string saveFF = "test.FF";
        public static string saveconv = "test.conv";

        public static string path = "";

        public static Net convNet;
        public static Net FFNet;



        /*
        public static int NUMBER_OF_LAYERS_IN_CONV_NET  = 6;
        public static int NUMBER_OF_LAYERS_IN_FF_NET = 3;

        public static List<int> NEURONS_PER_LAYER = new List<int>                { 80, 4, 2}; 

        public static List<int> LAYER_ID = new List<int>                         {  3, 1, 1, 1, 2,  0};//0=pool     1=conv  2=RLU   3=downsampling
        public static List<int> POOLING_ID = new List<int>                       {  0, 0, 0, 0, 0,  1};//0=average  1=max
        public static List<int> FILTER_PER_LAYER = new List<int>                 {  1, 4, 5, 4, 1,  1};
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_X = new List<int>   {  4, 2, 4, 2, 4, 21+216};   
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_Y = new List<int>   {  4, 3, 4, 3, 4, 38+93};

            */

        public static int numberOfInputImages = 1;

        public static List<Image_Data> storedImages = new List<Image_Data>();


        public static int NUMBER_OF_LAYERS_IN_CONV_NET = 4;
        public static int NUMBER_OF_LAYERS_IN_FF_NET = 5;

        public static List<int> NEURONS_PER_LAYER = new List<int> { 25, 2, 4, 3, 2 };

        public static List<int> LAYER_ID = new List<int>                        { 3, 1, 1, 0 };//0=pool     1=conv  2=RLU   3=downsampling
        public static List<int> POOLING_ID = new List<int>                      { 0, 1, 1, 1 };//0=average  1=max
        public static List<int> FILTER_PER_LAYER = new List<int>                { 1, 5, 5, 1 };
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_X = new List<int>  {25, 2, 2, 38};
        public static List<int> DIMENSION_OF_FILTER_IN_LAYER_Y = new List<int>  {25, 3, 3, 21};
        // Dimensionen: 950 | 525
        // Zerlegung: 950 = 2 * 5 * 5 * 19
        // Zerlegung: 525 = 3 * 5 * 5 * 7
        public static bool NetInitialized = false;



        public static void Load(string file)
        {




            string text = File.ReadAllText(@file);

            string[] parts = text.Split(':');

            string[] first = parts[0].Split(',');
            string[] second = parts[1].Split(';');

            string[] files = first[0].Split(';');

            string[] LayersID = first[1].Split(';');
            string[] LayersNum = first[2].Split(';');

            string[] dimensions = first[3].Split(';');

            int LayersInConv = Int32.Parse(LayersID[0]);
            int LayersInFF = Int32.Parse(second[0]);
            List<int> m_layerID = new List<int>();
            List<int> m_layerNum = new List<int>();



            List<int> FFNeurons = new List<int>();

            for (int i = 0; i < LayersID.Length - 2; i++)
            {
                m_layerID.Add(Int32.Parse(LayersID[i + 1]));
            }

            for (int i = 0; i < LayersNum.Length - 1; i++)
            {
                m_layerNum.Add(Int32.Parse(LayersNum[i]));
            }

            List<int> filterDimX = new List<int>();
            List<int> filterDimY = new List<int>();

            for (int i = 0; i < dimensions.Length - 1; i++)
            {
                filterDimX.Add(Int32.Parse(dimensions[i].Split('|')[0]));
                filterDimY.Add(Int32.Parse(dimensions[i].Split('|')[1]));

            }

            for (int i = 0; i < LayersInFF; i++)
            {
                FFNeurons.Add(Int32.Parse(second[i + 1]));
            }


            string[] patha = file.Split('/');
            string path = "";
            for (int i = 0; i < patha.Length - 1; i++)
            {
                path += patha[i] + "\\";
            }
            string p = "";
            if (path == "" || path == null)
            {
                p += System.Reflection.Assembly.GetExecutingAssembly().Location;


                patha = p.Split('\\');
                path = "";
                for (int i = 0; i < patha.Length - 1; i++)
                {
                    path += patha[i] + "\\";
                }
            }
            Console.WriteLine(path + files[1]);

            Program.path = path;
            Net testc = new Net();
            Net testf = new Net();
            NUMBER_OF_LAYERS_IN_CONV_NET = LayersInConv;
            NUMBER_OF_LAYERS_IN_FF_NET = LayersInFF;
            NEURONS_PER_LAYER = FFNeurons;
            LAYER_ID = m_layerID;
            POOLING_ID.Clear();
            for (int i = 0; i < NUMBER_OF_LAYERS_IN_CONV_NET - 1; i++)
            {
                POOLING_ID.Add(0);
            }
            POOLING_ID.Add(1);

            FILTER_PER_LAYER = m_layerNum;
            DIMENSION_OF_FILTER_IN_LAYER_X = filterDimX;
            DIMENSION_OF_FILTER_IN_LAYER_Y = filterDimY;

            testc.generateConvLoad(LayersInConv, m_layerNum, filterDimX, filterDimY);
            testc.loadConvNet(path + files[1], LayersInConv, m_layerNum, m_layerID, filterDimX, filterDimY, testc);

            testf.generateFFLoad(LayersInFF, FFNeurons);
            testf.loadFFNet(path + files[0], LayersInFF, FFNeurons, testf);
            int o = 0;


            FFNet = testf;
            testf.type = 1;

            convNet = testc;
            testc.type = 0;
        }





        public static Random random = new Random(Guid.NewGuid().GetHashCode());



        static void Main(string[] args)
        {
            Score.makeScoreNet();
            MenuLoop();
            // args[0] = "D:\\DQLCS\\DQL\\DQL\bin\\Network2.header";

            if (args.Length == 1)
            {

                Console.WriteLine("loading...");
                Load((string)args[0]);

                Interaction interaction = new Interaction();
                interaction.Interact();
                Console.WriteLine("ENDE");

                Console.ReadLine();

            }


            else
            {
                Console.WriteLine("creating");
                NeuralNet();
                Interaction interaction = new Interaction();
                interaction.Interact();
                Console.WriteLine("ENDE");
                Console.ReadLine();
            }
        }
        static void MenuLoop()
        {
            while (true)
            {
                Menu menu = new Menu();
                menu.ShowMenu();
                int input = menu.GetInput();
                switch (input)
                {
                    case (0):
                        Start();
                        break;
                    case (1):
                        Console.WriteLine("Where did you store the file?");
                        string inp = Console.ReadLine();
                        Load(inp);
                        break;
                    case (2):
                        //Save
                        break;
                    case (3):
                        return;
                }
            }
        }
        static void Start()
        {
            if (!NetInitialized)
            {
                NeuralNet();
            }

            Interaction interaction = new Interaction();
            interaction.Interact();
        }

        public static void NetToNet(Net C, Net F)
        {
            int numberOfInputsForNN = 0;
            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                numberOfInputsForNN += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length;
            }
            if (numberOfInputsForNN > Program.NEURONS_PER_LAYER[0])
            {
                Console.WriteLine();
                Console.Write("Warning: there are ");
                Console.Write(numberOfInputsForNN);
                Console.Write(" pictures to process but only ");
                Console.Write(Program.NEURONS_PER_LAYER[0]);
                Console.Write(" inputs in the FF! Do you want to go on? ");
                //Console.ReadLine();

            }
            else if (numberOfInputsForNN < Program.NEURONS_PER_LAYER[0])
            {
                Console.Write("Warning: there are ");
                Console.Write(numberOfInputsForNN);
                Console.Write(" pictures to process and ");
                Console.Write(Program.NEURONS_PER_LAYER[0]);
                Console.Write(" inputs in the FF! Do you want to go on? ");
                //Console.ReadLine();
            }

            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                for (int a = 0; a < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length; a++)
                {
                    // C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].showImage();
                    if (C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a] == null)
                    {
                        continue;
                    }
                    if (C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count == 1 && C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count == 1)
                    {

                        F.inputValues.Add(C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0][0]);
                    }
                    else if (C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length != 0 && C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0] != null)
                    {
                        string error;
                        error = "ERROR: UNFITTING IMAGE!!! Image should 1x1 but it is ";
                        error += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels.Count;
                        error += "x";
                        error += C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].pixels[0].Count;
                        Console.WriteLine(error);
                    }
                    else
                    {
                        string error;
                        error = "ERROR: 0-DIMENSIONAL IMAGE!!!";

                        Console.WriteLine(error);
                        throw new Exception();
                    }
                }
            }
            for (int i = 0; i < C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
            {
                //  C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_InputImages.Length();
                // C.convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length();
            }

        }




        static int NeuralNet()
        {

            convNet = new Net
            {
                filename = "",
                type = 0
            };
            convNet.generateStructure();
            convNet.CreateConvNet(false, convNet.structureVector);
            //convNet.Show();

            convNet.Save();

            FFNet = new Net
            {
                filename = "",
                type = 1
            };
            FFNet.generateStructure();
            FFNet.CreateFFNet(false, FFNet.structureVector);

            return 0;
        }
        public static void PassThrough()
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();

            Console.WriteLine("Conv");
            convNet.passThroughConv(true);
            Console.WriteLine("\tDone");
            NetToNet(convNet, FFNet);
            Console.WriteLine("FFNet");
            FFNet.passThroughFF();


            Console.WriteLine("\tDone");
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;

            Console.WriteLine(elapsedMs + " ms");
            //   Console.ReadLine();
        }
    }
}
