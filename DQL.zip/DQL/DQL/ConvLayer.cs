﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    class ConvLayer
    {
        public List<Filter> filter = new List<Filter>();

        public ConvLayer()
        {

        }


        public void freeMemory()
        {
            for (int i = 0; i < filter.Count(); i++)
            {
               // filter[i].filter_InputImages.Clear();
                //filter[i].filter_OutputImages.Clear();
            }
        }
    }
}
