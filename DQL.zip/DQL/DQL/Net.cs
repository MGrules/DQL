﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Threading.Tasks;

namespace DQL
{
    class Net
    {
        //public:
        object o = new object();
        public string filename;
        public int type;

        public List<ConvLayer> convLayer = new List<ConvLayer>();
        public List<FFLayer> FFLayer = new List<DQL.FFLayer>();
        public List<int> structureVector = new List<int>();
        public List<List<List<int>>> filterSize = new List<List<List<int>>>();

        public List<Image_Data> inputImages = new List<Image_Data>();

        public int numberOfFilter;
        public List<double> inputValues = new List<double>();
        //protected
        public List<double> Net_raw = new List<double>();
        public static Image_Data nullImage = new Image_Data();
        //private
        public static int downSamplingSizeX;
        public static int downSamplingSizeY;

        //Funktionen
        public Net()
        {

        }


        public void generateStructure()
        {
            List<int> structure = new List<int>();

            if (type == 0)
            {

                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
                {
                    structure.Add(Program.FILTER_PER_LAYER[i]);
                    numberOfFilter += Program.FILTER_PER_LAYER[i];

                }
                structureVector = structure;



                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
                {             //1
                    List<List<int>> templayer = new List<List<int>>();
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {             //2
                        List<int> tempfilter = new List<int>();
                        for (int b = 0; b < 2; b++)
                        {
                            tempfilter.Add(Program.DIMENSION_OF_FILTER_IN_LAYER_X[i]);
                            tempfilter.Add(Program.DIMENSION_OF_FILTER_IN_LAYER_Y[i]);
                        }
                        templayer.Add(tempfilter);
                    }
                    filterSize.Add(templayer);
                }

            }
            else if (type == 1)
            {

                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_FF_NET; i++)
                {
                    structure.Add(Program.NEURONS_PER_LAYER[i]);
                }
                structureVector = structure;

            }
        }


        public void CreateConvNet(bool load, List<int> structureVector)
        {
            if (load)
            {
                Program.Load("Network1.header");

            }
            else
            {
                makeConvNet();
                return;
            }
        }

        public void loadConvNet(string file, int layers, List<int> layerNum, List<int> LayerID, List<int> dimx, List<int> dimy, Net convNet)
        {
            string text = File.ReadAllText(@file);
            string[] weights = text.Split(';');



            int index = 0;

            for (int a = 0; a < layers; a++)
            {
                if (LayerID[a] == 1)
                {

                    ConvLayer tempLayer = new ConvLayer();
                    Filter tempFilter = new Filter(a);
                    tempFilter.weights.Clear();

                    for (int i = 0; i < dimy[a]; i++)
                    {
                        List<Weight> tempV = new List<Weight>();
                        for (int c = 0; c < dimx[a]; c++)
                        {
                            double temp = Convert.ToDouble(weights[index]);
                            Weight w = new Weight();
                            w.w = temp;
                            tempV.Add(w);
                            index++;
                        }
                        tempFilter.weights.Add(tempV);
                        tempFilter.height = dimy[a];
                        tempFilter.width = dimx[a];
                    }

                    for (int b = 0; b < layerNum[a]; b++)
                    {

                        tempLayer.filter.Add(tempFilter);


                    }
                    convLayer.Add(tempLayer);

                }
                else
                {
                    ConvLayer tempLayer = new ConvLayer();
                    Filter tempFilter = new Filter(a);
                    tempFilter.weights.Clear();
                    tempFilter.height = dimy[a];
                    tempFilter.width = dimx[a];
                    tempLayer.filter.Add(tempFilter);
                    convLayer.Add(tempLayer);
                }
            }






        }



        public void loadFFNet(string file, int layers, List<int> layerNum, Net FFNet)
        {


            string text = File.ReadAllText(@file);
            string[] weights = text.Split(';');
            double test = Convert.ToDouble(weights[0]);

            for (int i = 0; i < layers; i++)
            {
                FFNet.FFLayer.Add(new FFLayer());
            }

            for (int i = 0; i < layers; i++)
            {
                for (int a = 0; a < layerNum[i]; a++)
                {
                    FFNet.FFLayer[i].neurons.Add(new FFNeuron());
                }
            }




            int index = 0;

            for (int i = 0; i < layers - 1; i++)
            {
                FFLayer fs = new FFLayer();
                for (int a = 0; a < layerNum[i]; a++)
                {
                    FFNeuron fF = new FFNeuron();
                    for (int b = 0; b < layerNum[i + 1]; b++)
                    {


                        FFLayer[i].neurons[a].weightsToNextNeurons.Add(Convert.ToDouble(weights[index]));
                        index++;
                    }


                }

            }

        }


        public void generateFFLoad(int layers, List<int> neurons)
        {
            structureVector.Clear();
            List<int> structure = new List<int>();

            for (int i = 0; i < layers; i++)
            {
                structure.Add(neurons[i]);
                numberOfFilter += neurons[i];

            }
            structureVector = structure;



            for (int i = 0; i < layers; i++)
            {             //1
                List<List<int>> templayer = new List<List<int>>();
                for (int a = 0; a < neurons[i]; a++)
                {             //2
                    List<int> tempfilter = new List<int>();

                    templayer.Add(tempfilter);
                }
                filterSize.Add(templayer);
            }

        }





        public void generateConvLoad(int LayersInConv, List<int> m_layerNum, List<int> filterDimX, List<int> filterDimY)
        {
            structureVector.Clear();
            List<int> structure = new List<int>();


            for (int i = 0; i < LayersInConv; i++)
            {
                structure.Add(m_layerNum[i]);
                numberOfFilter += m_layerNum[i];

            }
            structureVector = structure;



            for (int i = 0; i < LayersInConv; i++)
            {             //1
                List<List<int>> templayer = new List<List<int>>();
                for (int a = 0; a < m_layerNum[i]; a++)
                {             //2
                    List<int> tempfilter = new List<int>();
                    for (int b = 0; b < 2; b++)
                    {
                        tempfilter.Add(filterDimX[i]);
                        tempfilter.Add(filterDimY[i]);
                    }
                    templayer.Add(tempfilter);
                }
                filterSize.Add(templayer);
            }

        }

        public void Save()
        {
            /*
            FileStream f = new FileStream("test.FF", FileMode.Create);
            //FileStream h = new FileStream("Network1.header", FileMode.Create);
            FileStream c = new FileStream("test.conv", FileMode.Create);

            BinaryWriter bwf = new BinaryWriter(f);
            //BinaryWriter bwh = new BinaryWriter(h);
            
            BinaryWriter bwc = new BinaryWriter(c);
            */

            StreamWriter header = new StreamWriter(Program.path + Program.saveName, false);
            StreamWriter conv = new StreamWriter(Program.path + Program.saveconv, false);
            StreamWriter FF = new StreamWriter(Program.path + Program.saveFF, false);

            //---------------------------------------------------------------------------------HEADER
            int cl = 0;

            cl += Program.NUMBER_OF_LAYERS_IN_CONV_NET * 2; //2 bytes per layer
            cl += Program.NUMBER_OF_LAYERS_IN_FF_NET * 2;




            header.Write(Program.saveFF + ";" + Program.saveconv + ",");




            header.Write(Program.NUMBER_OF_LAYERS_IN_CONV_NET + ";");
            foreach (int ID in Program.LAYER_ID)
            {
                header.Write(ID + ";");
            }
            header.Write(",");

            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                header.Write(Program.FILTER_PER_LAYER[i] + ";");
            }

            header.Write(",");

            //---------------------------------------------------------------------------------/HEADER



            //---------------------------------------------------------------------------------CONV HEADER

            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                header.Write(Program.DIMENSION_OF_FILTER_IN_LAYER_X[i] + "|" + Program.DIMENSION_OF_FILTER_IN_LAYER_Y[i] + ";");

            }
            header.Write(",");
            //---------------------------------------------------------------------------------/CONV HEADER

            for (int a = 0; a < Program.convNet.convLayer.Count; a++)
            {

                for (int b = 0; b < Program.convNet.convLayer[a].filter.Count; b++)
                {

                    for (int e = 0; e < Program.convNet.convLayer[a].filter[b].weights.Count; e++)
                    {

                        for (int d = 0; d < Program.convNet.convLayer[a].filter[b].weights[e].Count; d++)
                        {


                            // write_to_bin_stream(&f,convLayer[a].filter[b].weights[c][d],8);
                            conv.Write(Program.convNet.convLayer[a].filter[b].weights[e][d] + ";");

                            //   double temp=convLayer[a].filter[b].weights[c][d];
                            //   f.write(reinterpret_cast<char*>(&temp),sizeof temp);

                        }

                    }

                }


            }
            header.Write(":");
            header.Write(Program.NUMBER_OF_LAYERS_IN_FF_NET + ";");

            foreach (int N in Program.NEURONS_PER_LAYER)
            {
                header.Write(N + ";");
            }

            for (int a = 0; a < FFLayer.Count; a++)
            {

                for (int b = 0; b < FFLayer[a].neurons.Count; b++)
                {

                    for (int e = 0; e < FFLayer[a].neurons[b].weightsToNextNeurons.Count; e++)
                    {




                        // write_to_bin_stream(&f,convLayer[a].filter[b].weights[c][d],8);
                        FF.Write(FFLayer[a].neurons[b].weightsToNextNeurons[e] + ";");

                        //   double temp=convLayer[a].filter[b].weights[c][d];
                        //   f.write(reinterpret_cast<char*>(&temp),sizeof temp);



                    }

                }


            }


            header.Close();
            conv.Close();
            FF.Close();
        }


        public void Show()
        {

            if (type == 0)
            {
                for (int a = 0; a < convLayer.Count; a++)
                {
                    Console.WriteLine();
                    Console.WriteLine("layer number: " + a);

                    for (int b = 0; b < convLayer[a].filter.Count; b++)
                    {
                        Console.WriteLine();
                        for (int c = 0; c < convLayer[a].filter[b].weights.Count; c++)
                        {
                            Console.WriteLine();
                            for (int d = 0; d < convLayer[a].filter[b].weights[c].Count; d++)
                            {
                                //cout<<endl;
                                Console.Write(convLayer[a].filter[b].weights[c][d] + ";");


                            }

                        }

                    }


                }
            }
            else if (type == 1)
            {

                for (int a = 0; a < Program.NUMBER_OF_LAYERS_IN_FF_NET; a++)
                {

                    Console.WriteLine();
                    Console.WriteLine("FF layer number: " + a);

                    for (int b = 0; b < Program.NEURONS_PER_LAYER[a]; b++)
                    {
                        Console.WriteLine();
                        for (int c = 0; c < FFLayer[a].neurons[b].weightsToNextNeurons.Count; c++)
                        {

                            Console.WriteLine(FFLayer[a].neurons[b].weightsToNextNeurons[c]);
                        }
                        Console.WriteLine();
                    }


                }


            }
        }


        public void getImage(Bitmap bitmap)
        {
            Image_Data img = new Image_Data(bitmap);
            inputImages.Clear();
            inputImages.Add(img);
        }


        public void passThroughFF()
        {
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_FF_NET; i++)
            {
                if (i == 0)
                {
                    for (int x = 0; x < FFLayer[0].neurons.Count; x++)
                    {
                        for (int y = 0; y < inputValues.Count; y++)
                        {
                            FFLayer[0].neurons[x].outputValue += (inputValues[y]);
                        }
                    }

                    for (int x = 0; x < FFLayer[0].neurons.Count; x++)
                    {
                        FFLayer[0].neurons[x].calculateSum();
                    }
                    continue;
                }





                for (int a = 0; a < Program.NEURONS_PER_LAYER[i - 1]; a++)
                {

                    for (int b = 0; b < Program.NEURONS_PER_LAYER[i]; b++)
                    {
                        if (i < Program.NUMBER_OF_LAYERS_IN_FF_NET)
                        {
                            FFLayer[i].neurons[b].outputValue += (FFLayer[i - 1].neurons[a].weightsToNextNeurons[b] * FFLayer[i - 1].neurons[a].outputValue);
                        }
                    }
                    Parallel.For(0, FFLayer[i].neurons.Count, z =>
                  {
                      FFLayer[i].neurons[z].calculateSum();
                  });


                    FFLayer[i].freeMemory();
                }




            }

            for (int y = 0; y < Program.NUMBER_OF_LAYERS_IN_FF_NET; y++)
            {

                FFLayer[y].freeMemory();
            }
        }
        public void passThroughConv(List<Bitmap> input, bool clear)
        {
            inputImages.Clear();
            for (int a = 0; a < input.Count; a++)
            {
                inputImages.Add(new Image_Data(input[a]));
            }
            passThroughConv(clear);
        }
        public void passThroughConv(bool clear)
        {
            Console.WriteLine("\t" + inputImages.Count + "\t" + Program.NUMBER_OF_LAYERS_IN_CONV_NET);
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                Console.WriteLine("Currently in Layer " + i + " of " + Program.NUMBER_OF_LAYERS_IN_CONV_NET + " the conv; Layer ID = " + Program.LAYER_ID[i]);

                //        cout<<"-----------------------------------------"<<endl
                if (i == 0)
                {

                    Parallel.For(0, Program.FILTER_PER_LAYER[i], a =>
                   {
                       for (int b = 0; b < inputImages.Count; b++)
                       {
                           lock (o)
                           {
                               convLayer[i].filter[a].filter_InputImages[b] = (inputImages[b]);
                               convLayer[i].filter[a].outputImagesNumber = inputImages.Count;
                           }
                       }
                       switch (Program.LAYER_ID[0])
                       {
                           case 0: convLayer[i].filter[a].pooling(Program.POOLING_ID[0]); break;
                           case 1: convLayer[i].filter[a].useFilter(); break;
                           case 2: convLayer[i].filter[a].RLU(); break;
                           case 3: convLayer[i].filter[a].downSample(); break;
                       }


                   });

                    Image_Data img = convLayer[i].filter[0].filter_OutputImages[0];
                    Bitmap bmp = new Bitmap(img.width, img.height);
                    for (int a = 0; a < img.height; a++)
                    {
                        for (int b = 0; b < img.width; b++)
                        {
                            int val = img.pixels[a][b] == 0 ? 0 : (int)(255 * img.pixels[a][b]);
                            Color c;
                            try
                            {
                                c = Color.FromArgb(0, val, val, val);
                            }
                            catch (Exception e) { c = Color.FromArgb(0, 0, 0, 0); }

                            bmp.SetPixel(b, a, c);
                        }
                    }
                    bmp.Save("D:/NewScreen.bmp", System.Drawing.Imaging.ImageFormat.Bmp);
                    if (Program.storedImages.Count == 10)
                    {
                        Program.storedImages.RemoveAt(0);
                    }
                    Program.storedImages.Add(img);

                    if (clear)
                        convLayer[i].freeMemory();


                    continue;

                }

                if (Program.LAYER_ID[i] == 0)       //pooling
                {
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    // convLayer[i].filter[a].filter_InputImages[c] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    convLayer[i].filter[a].filter_InputImages[(convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    convLayer[i].filter[a].outputImagesNumber = convLayer[i].filter[a].filter_OutputImages.Length;
                                    Console.WriteLine(i + ":  " + convLayer[i].filter[a].width + "_" + convLayer[i].filter[a].height);
                                }
                            });

                        }
                        //convLayer[i].filter[a].pooling(Program.POOLING_ID[i]);
                    };


                    Parallel.For(0, Program.FILTER_PER_LAYER[i], a =>
                    {
                        convLayer[i].filter[a].pooling(Program.POOLING_ID[i]);
                    });
                    if (clear)
                        convLayer[i].freeMemory();


                }
                else if (Program.LAYER_ID[i] == 1)
                {
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {

                            Parallel.For(0, convLayer[i - 1].filter[b].outputImagesNumber, c =>
                          {
                              lock (o)
                              {
                                  convLayer[i].filter[a].filter_InputImages[(convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                  convLayer[i].filter[a].outputImagesNumber = convLayer[i].filter[a].filter_OutputImages.Length;

                              }
                          });

                            // convLayer[i - 1].filter[b].filter_OutputImages.Clear();
                        }

                        //  convLayer[i].filter[a].useFilter();


                    }
                    Parallel.For(0, Program.FILTER_PER_LAYER[i], a =>
                    {
                        convLayer[i].filter[a].useFilter();

                    });

                    Parallel.For(0, Program.FILTER_PER_LAYER[i - 1], a =>
                    {
                        convLayer[i - 1].filter[a].outputImagesNumber = 0;
                    });
                    Console.WriteLine(i + ":  " + convLayer[i].filter[0].filter_OutputImages[0].width + "_" + convLayer[i].filter[0].filter_OutputImages[0].height);
                    if (clear)
                        convLayer[i].freeMemory();


                }
                else if (Program.LAYER_ID[i] == 2)
                {

                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    convLayer[i].filter[a].filter_InputImages[(convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    convLayer[i].filter[a].outputImagesNumber = convLayer[i].filter[a].filter_OutputImages.Length;
                                    Console.WriteLine(i + ":  " + convLayer[i].filter[a].filter_OutputImages[0].width + "_" + convLayer[i].filter[a].filter_OutputImages[0].height);
                                }
                            });
                        }
                        //convLayer[i].filter[a].RLU();
                    };

                    Parallel.For(0, Program.FILTER_PER_LAYER[i], a =>
                    {
                        convLayer[i].filter[a].RLU();
                    });
                    Parallel.For(0, Program.FILTER_PER_LAYER[i - 1], a =>
                    {
                        convLayer[i - 1].filter[a].outputImagesNumber = 0;
                    });
                    Console.WriteLine(i + ":  " + convLayer[i].filter[0].filter_OutputImages[0].width + "_" + convLayer[i].filter[0].filter_OutputImages[0].height);

                    if (clear)
                        convLayer[i].freeMemory();

                }
                else if (Program.LAYER_ID[i] == 3)
                {

                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            Parallel.For(0, convLayer[i - 1].filter[b].outputImagesNumber, c =>
                            {
                                lock (o)
                                {
                                    convLayer[i].filter[a].filter_InputImages[(convLayer[i - 1].filter[b].outputImagesNumber * b + c)] = (convLayer[i - 1].filter[b].filter_OutputImages[c]);
                                    convLayer[i].filter[a].outputImagesNumber = convLayer[i].filter[a].filter_OutputImages.Length;
                                    Console.WriteLine(i + ":  " + convLayer[i].filter[a].filter_OutputImages[0].width + "_" + convLayer[i].filter[a].filter_OutputImages[0].height);
                                }
                            });
                        }

                        convLayer[i].filter[a].downSample();
                    }
                    Console.WriteLine(i + ":  " + convLayer[i].filter[0].filter_OutputImages[0].width + "_" + convLayer[i].filter[0].filter_OutputImages[0].height);

                    convLayer[i].freeMemory();
                    Parallel.For(0, Program.FILTER_PER_LAYER[i - 1], a =>
                    {
                        convLayer[i].filter[a].outputImagesNumber = 0;
                    });
                }
            }
            /*
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1; i++)
            {
                for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                {
                   // convLayer[i].filter[a].filter_InputImages.Clear();
                   //convLayer[i].filter[a].filter_OutputImages.Clear();
                }
            }
            */
        }


        public void CreateFFNet(bool load, List<int> structureVector)
        {
            if (load)
            {
                Program.Load("");
            }
            else
            {
                makeFFNet();
                return;
            }


        }

        public int showResult()
        {
            if (type == 0)
            {
                //  Console.WriteLine(convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[0].filter_OutputImages.Count);

                for (int i = 0; i < convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
                {
                    for (int a = 0; a < convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Length; a++)
                    {
                        //convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].showImage();
                    }
                }
                Console.WriteLine();
                return -1;
            }
            else if (type == 1)
            {
                // Console.WriteLine(FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET-1].neurons[])
                int max = 0;
                double highestVal = -1;
                for (int a = 0; a < Program.NEURONS_PER_LAYER[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1]; a++)
                {
                    if (FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue > highestVal)
                    {
                        max = a;
                        highestVal = FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue;
                    }

                    Console.WriteLine(FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue);
                }

                return max;
            }
            return -1;

        }



        //protected:


        //private:
        private void write_to_bin_stream(BinaryWriter f, int number, int length)
        {
            if (f != null)
            {
                for (int i = 0; i < length; i++)
                {
                    f.Write(int_to_hex(number, length)[i]);
                    f.Flush();
                }

            }
            else Console.WriteLine("error");

        }


        private string int_to_hex(int i, int l)
        {
            string temp = "";
            for (int a = 0; a < l; a++)
            {
                temp += i;
                i >>= 8;
            }
            return temp;
        }


        private void makeFFNet()
        {
            for (int a = 0; a < Program.NUMBER_OF_LAYERS_IN_FF_NET; a++)
            {

                FFLayer tempLayer = new FFLayer();

                tempLayer.neurons.Clear();
                for (int b = 0; b < Program.NEURONS_PER_LAYER[a]; b++)
                {
                    FFNeuron tempNeuron = new FFNeuron();
                    if (a < Program.NUMBER_OF_LAYERS_IN_FF_NET - 1)
                    {

                        tempNeuron.getRandom(Program.NEURONS_PER_LAYER[a + 1]);


                        tempLayer.neurons.Add(tempNeuron);

                    }
                    else
                    {
                        tempNeuron.BIAS = 0;
                        tempLayer.neurons.Add(tempNeuron);
                    }


                }
                FFLayer.Add(tempLayer);

            }



        }


        private void makeConvNet()
        {
            for (int a = 0; a < structureVector.Count; a++)
            {

                ConvLayer tempLayer = new ConvLayer();
                Filter tempFilter = new Filter(a);

                for (int b = 0; b < structureVector[a]; b++)
                {

                    tempFilter.weights.Clear();


                    if (Program.LAYER_ID[a] == 1)
                    {
                        tempFilter.getRandom(filterSize[a][b][0], filterSize[a][b][1]);
                    }
                    else
                    {
                        tempFilter.height = Program.DIMENSION_OF_FILTER_IN_LAYER_Y[a];
                        tempFilter.width = Program.DIMENSION_OF_FILTER_IN_LAYER_X[a];
                    }



                    tempLayer.filter.Add(tempFilter);


                }
                convLayer.Add(tempLayer);

            }


            Console.WriteLine("Done making new net ");
            return;
        }







        private int getNetData()
        {
            FileStream stream = new FileStream(filename, FileMode.Open);
            BinaryReader f = new BinaryReader(stream);

            if (stream == null)
            {
                Console.WriteLine("error loading file " + filename);
                return -1;
            }

            List<char> fileCHAR = new List<char>();
            char current = f.ReadChar();
            while (current != '\0')
            {
                fileCHAR.Add(current);
                current = f.ReadChar();
            }


            return 0;

        }

        private int CalculateBytes(List<char> v, int start, int finish)
        {
            int result = 0;


            for (int a = start; a <= finish; a++)
            {

                result += (int)Math.Pow(16.0, 2.0 * (a - start)) * v[a];

            }

            return result;

        }



        //--------------------------------------------------------------------------------BACKPROP-----------------------------------------------------------------------//

        public double getError(List<double> wanted, int i)
        {

            double temp = 0.0;

            temp = FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[i].outputValue - wanted[i];

            return temp;
        }

        public double[] getV()
        {
            double[] res = new double[FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons.Count];

            for (int a = 0; a < FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons.Count; a++)
            {
                res[a] = FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue;
            }

            return res;
        }


        public List<double> backpassFF(List<double> wanted)
        {

            //den output Neuronen die Fehler zuweisen
            for (int i = 0; i < Program.NEURONS_PER_LAYER[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1]; i++)
            {
                FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[i].error = getError(wanted, i);
                Console.WriteLine("Error [" + i + "]: " + FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[i].error);
            }


            //beginnend beim vorletzten Layer
            for (int i = Program.NUMBER_OF_LAYERS_IN_FF_NET - 2; i >= 0; i--)
            {

                for (int b = 0; b < Program.NEURONS_PER_LAYER[i + 1]; b++)
                {
                    double sum = 0;
                    for (int c = 0; c < Program.NEURONS_PER_LAYER[i]; c++)
                    {
                        sum += Math.Abs(FFLayer[i].neurons[c].weightsToNextNeurons[b]);
                    }
                    sum += FFLayer[i + 1].neurons[b].BIAS;
                    double part = 0;
                    double contribution = 0;
                    for (int a = 0; a < Program.NEURONS_PER_LAYER[i]; a++)
                    {
                        part = Math.Abs(FFLayer[i].neurons[a].weightsToNextNeurons[b]) / sum;
                        contribution = part * FFLayer[i + 1].neurons[b].error;
                        FFLayer[i].neurons[a].error += contribution / Program.NEURONS_PER_LAYER[i + 1];
                        FFLayer[i].neurons[a].weightsToNextNeurons[b] = FFLayer[i].neurons[a].weightsToNextNeurons[b] - 2 * contribution;
                    }
                    part = Math.Abs(FFLayer[i + 1].neurons[b].BIAS) / sum;
                    contribution = part * FFLayer[i + 1].neurons[b].error;
                    FFLayer[i + 1].neurons[b].BIAS -= 2 * contribution;
                }

            }
            List<double> inputError = new List<double>();
            for (int a = 0; a < Program.NEURONS_PER_LAYER[0]; a++)
            {
                inputError.Add(FFLayer[0].neurons[a].error);
            }
            return inputError;
        }



        public void backpassConv(List<double> error)
        {
            error.RemoveRange(25, error.Count - 25);
            Console.WriteLine(" ".ToString().PadLeft(24, '='));
            Console.WriteLine("Number of errors: " + error.Count);

            List<int> layerPicked = new List<int>();
            for (int a = 0; a < Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1; a++) // das downscaling layer wird ausgelassen
            {
                layerPicked.Add(0);
            }


            for (int picNum = 0; picNum < error.Count; picNum++)
            {
                passThroughConv(false);
                AddOne(layerPicked);
                List<List<double>> lastError = new List<List<double>>() { new List<double>() { error[picNum] } };
                Image_Data img = convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[0].filter_OutputImages[picNum];
                for (int c = layerPicked.Count - 1; c >= 0; c--)
                {
                    List<List<double>> pixelError = new List<List<double>>();
                    Image_Data cameFrom = img.belongsToInputImage;
                    Console.WriteLine(Program.LAYER_ID[c + 1]);
                    if (Program.LAYER_ID[c + 1] == 0) // da 0 immer ein downscale Layer ist, und das nicht trainiert werden kann, wird es übersprungen
                    {
                        if (Program.POOLING_ID[c + 1] == 0)
                        {//average pooling
                            int FilterSize = Program.convNet.convLayer[c + 1].filter[layerPicked[c]].height * Program.convNet.convLayer[c + 1].filter[layerPicked[c]].width;
                            List<List<int>> times = new List<List<int>>();
                            Console.WriteLine(lastError[0][0] + ": " + FilterSize);
                            for (int y = 0; y < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].filter_InputImages[0].height; y++)
                            {
                                List<int> rowTimes = new List<int>();
                                List<double> temp = new List<double>();
                                for (int x = 0; x < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].filter_InputImages[0].width; x++)
                                {
                                    temp.Add(0);
                                    rowTimes.Add(0);
                                }
                                pixelError.Add(temp);
                                times.Add(rowTimes);
                            }

                            for (int y = 0; y <= pixelError.Count - Program.convNet.convLayer[c + 1].filter[layerPicked[c]].height; y++)
                            {
                                for (int x = 0; x <= pixelError[y].Count - Program.convNet.convLayer[c + 1].filter[layerPicked[c]].width; x++)
                                {
                                    for (int dy = 0; dy < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].height; dy++)
                                    {
                                        for (int dx = 0; dx < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].width; dx++)
                                        {
                                            times[y + dy][x + dx]++;
                                            pixelError[y + dy][x + dx] += lastError[y][x];
                                        }
                                    }
                                }
                            }
                            for (int y = 0; y < pixelError.Count; y++)
                            {
                                for (int x = 0; x < pixelError[y].Count; x++)
                                {
                                    if (times[y][x] == 0)
                                        Console.WriteLine("ERR");
                                    pixelError[y][x] /= times[y][x];
                                }
                            }
                            for (int a = 0; a < pixelError.Count; a++)
                            {
                                for (int b = 0; b < pixelError[a].Count; b++)
                                {
                                    Console.Write(Math.Floor(pixelError[a][b] * Math.Pow(10, 7)) / 100 + " | ");
                                }
                                Console.WriteLine();
                            }
                        }
                        else
                        {//max pooling
                            int inputPicture = 0;

                            for (int y = 0; y < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].filter_InputImages[0].height; y++)
                            {
                                List<double> temp = new List<double>();
                                for (int x = 0; x < Program.convNet.convLayer[c + 1].filter[layerPicked[c]].filter_InputImages[0].width; x++)
                                {
                                    temp.Add(0);
                                }
                                pixelError.Add(temp);
                            }
                            Filter filter = convLayer[c + 1].filter[layerPicked[c]];
                            if (filter.filter_InputImages.Length <= inputPicture)
                            {
                                Console.WriteLine("Index out of bounds: [" + filter.filter_InputImages.Length + ";" + inputPicture + "]" + picNum);
                                Console.ReadLine();
                            }
                            double errorsum = 0;
                            for (int a = 0; a < lastError.Count; a++)
                            {
                                for (int b = 0; b < lastError[a].Count; b++)
                                {
                                    errorsum += lastError[a][b] / (filter.filter_OutputImages[0].width * filter.filter_OutputImages[0].height);
                                }
                            }
                            double highest = 0;
                            int hX = 0;
                            int hY = 0;
                            for (int a = 0; a < filter.filter_InputImages[0].height; a++)
                            {
                                for (int b = 0; b < filter.filter_InputImages[0].width; b++)
                                {
                                    if (highest < cameFrom.pixels[a][b])
                                    {
                                        highest = cameFrom.pixels[a][b];
                                        hX = b;
                                        hY = a;
                                    }
                                }
                            }
                            Console.WriteLine(hX + "|" + hY + "\t" + highest);
                            pixelError[hY][hX] = errorsum;
                             
                            Image_Data prev = cameFrom;
                        }
                        //Console.ReadLine();
                        img = cameFrom;
                    }
                    else if (Program.LAYER_ID[c + 1] == 1)
                    {
                        int fNum = layerPicked[c];
                        List<List<int>> times = new List<List<int>>();

                        for (int y = 0; y < lastError.Count; y++)
                        {
                            List<int> rowTimes = new List<int>();
                            List<double> temp = new List<double>();
                            for (int x = 0; x < lastError[y].Count; x++)
                            {
                                temp.Add(0);
                                rowTimes.Add(0);
                            }
                            pixelError.Add(temp);
                            times.Add(rowTimes);
                        }
                        Filter filter = Program.convNet.convLayer[c + 1].filter[fNum];
                        List<List<int>> FilterTimes = new List<List<int>>();
                        List<List<double>> FilterPixelError = new List<List<double>>();
                        for (int y = 0; y < filter.height; y++)
                        {
                            List<int> fT = new List<int>();
                            List<double> temp = new List<double>();
                            for (int x = 0; x < filter.width; x++)
                            {
                                Console.Write(filter.weights[y][x].w + "|");
                                fT.Add(0);
                                temp.Add(0);
                            }
                            Console.WriteLine();
                            FilterTimes.Add(fT);
                            FilterPixelError.Add(temp);
                        }
                        //Console.ReadLine();
                        for (int y = 0; y < lastError.Count; y++)
                        {
                            for (int x = 0; x < lastError[y].Count; x++)
                            {

                                int yV = y - (int)Math.Floor((double)filter.height / 2);
                                int xV = x - (int)Math.Floor((double)filter.width / 2);
                                double currentError = lastError[y][x];
                                for (int dx = 0; dx < filter.width; dx++)
                                {
                                    for (int dy = 0; dy < filter.height; dy++)
                                    {
                                        if (xV + dx >= 0 && yV + dy >= 0 && yV + dy < pixelError.Count && xV + dx < pixelError[yV + dy].Count)
                                        {
                                            double w = filter.weights[dy][dx].w;
                                            pixelError[yV + dy][xV + dx] += w * currentError;
                                            times[yV + dy][xV + dx]++;
                                        }
                                    }
                                }
                            }
                        }
                        for (int y = 0; y < lastError.Count; y++)
                        {
                            for (int x = 0; x < lastError[y].Count; x++)
                            {
                                pixelError[y][x] /= times[y][x];
                            }
                        }
                        for (int y = 0; y < lastError.Count; y++)
                        {
                            for (int x = 0; x < lastError[y].Count; x++)
                            {

                                int yV = y - (int)Math.Floor((double)filter.height / 2);
                                int xV = x - (int)Math.Floor((double)filter.width / 2);
                                for (int dx = 0; dx < filter.width; dx++)
                                {
                                    for (int dy = 0; dy < filter.height; dy++)
                                    {
                                        if (xV + dx >= 0 && yV + dy >= 0 && yV + dy < pixelError.Count && xV + dx < pixelError[yV + dy].Count)
                                        {
                                            FilterPixelError[dy][dx] += pixelError[yV + dy][xV + dx];
                                            FilterTimes[dy][dx]++;
                                        }
                                    }
                                }
                            }
                        }
                        for (int y = 0; y < filter.height; y++)
                        {
                            for (int x = 0; x < filter.width; x++)
                            {
                                Weight w = new Weight();
                                w.w = filter.weights[y][x].w;
                                w.delta += FilterPixelError[y][x] / FilterTimes[y][x];
                                filter.weights[y][x] = w;
                            }
                        }
                        img = cameFrom;

                    }

                    lastError = pixelError;
                }
                Console.WriteLine("________________________________________");
            }

        }

        public void AddOne(List<int> layer)
        {
            for (int a = 0; a < layer.Count; a++)
            {
                layer[a]++;
                if (layer[a] < Program.FILTER_PER_LAYER[a + 1])
                {
                    return;
                }
                layer[a] = 0;
            }
        }
    }
}
