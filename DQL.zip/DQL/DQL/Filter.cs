﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DQL
{
    struct Weight
    {
        public double w;
        public double delta;
    }
    class Filter
    {

        public double error;
        public int width;
        public int height;
        public Image_Data[] filter_InputImages;
        public Image_Data[] filter_OutputImages;
        public int outputImagesNumber = 0;
        public List<List<Weight>> weights = new List<List<Weight>>();
        public Filter(int LayerID)
        {
            int ImagesUpToHere = Program.numberOfInputImages;
            for (int i = 0; i < LayerID; i++)
            {
                ImagesUpToHere *= Program.FILTER_PER_LAYER[i];

            }

            Image_Data[] z = new Image_Data[ImagesUpToHere];
            Image_Data[] u = new Image_Data[ImagesUpToHere];



            filter_OutputImages = u;
            filter_InputImages = z;
        }


        public void RLU()
        {
            Parallel.For(0, filter_InputImages.Length, i =>
         {
             if (filter_InputImages[i] != null)
             {
                 Image_Data image = new Image_Data();
                 image.height = filter_InputImages[i].height;
                 image.width = filter_InputImages[i].width;
                 image.pixels.Clear();
                 for (int y = 0; y < filter_InputImages[i].height; y++)
                 {
                     List<double> pixels = new List<double>();
                     for (int x = 0; x < filter_InputImages[i].width; x++)
                     {
                         pixels.Add(TRANSFER(filter_InputImages[i].pixels[y][x]));
                         //                cout<<pixels.back()<<endl;
                     }
                     image.pixels.Add(pixels);
                 }
                 filter_OutputImages[i] = image;
             }
         });
            Console.WriteLine(width + "|" + height + " : " + filter_OutputImages.Length);
        }
        public void singleFilter()
        {
            //neues Bild
            Image_Data result = new Image_Data();
            //selbe Maße
            result.height = 1;
            result.width = 1;

            double temp = 0;
            for (int i = 0; i < filter_InputImages[0].height; i++)
            {
                for (int a = 0; a < filter_InputImages[0].width; a++)
                {
                    temp += 1 - abs(filter_InputImages[0].pixels[i][a] - weights[i][a].w);
                }
            }
            int pixels = height * width;
            temp = temp / pixels;
            List<List<double>> tem = new List<List<double>>();
            List<double> t = new List<double>();
            t.Add(temp);
            tem.Add(t);
            result.pixels.Add(t);

            filter_OutputImages[0] = (result);
        }

        private double abs(double v)
        {
            if (v > 0) { return v; } else return -v;
        }

        public void useFilter()
        {

            Parallel.For(0, filter_InputImages.Length, e =>
          {
              if (filter_InputImages[e] != null)
              {
                  //neues Bild
                  Image_Data result = new Image_Data();
                  result.belongsToInputImage = filter_InputImages[e];
                  //selbe Maße
                  result.height = filter_InputImages[e].height;
                  result.width = filter_InputImages[e].width;
                  //result.pixels.clear();


                  for (int i = 0; i < filter_InputImages[e].height; i++)
                  {
                      List<double> temp = new List<double>();
                      for (int a = 0; a < filter_InputImages[e].width; a++)
                      {
                          //DEBUG
                          //result.pixels[i][a]=compareFilter(e,i,a);
                          double tempe = compareFilter(e, i, a);

                          temp.Add(tempe);

                      }
                      result.pixels.Add(temp);
                  }
                  filter_OutputImages[e] = (result);
                  //        cout<<filter_OutputImages.size()<<endl;
              }
          });
            Console.WriteLine(width + "|" + height + " : " + filter_OutputImages.Length);
        }


        public double compareFilter(int e, int i, int a)
        {
            //e = ID
            //i = y
            //a = x
            Image_Data picture = filter_InputImages[e];


            double temp = 0;
            int topLeftCornery = 0;
            int topLeftCornerx = 0;


            topLeftCornerx = a - ((width - 1) / 2);
            topLeftCornery = i - ((height - 1) / 2);


            int filters = 0;

            int current_posx = topLeftCornerx;
            int current_posy = topLeftCornery;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                    {
                        //  temp += picture.pixels[current_posx + x][current_posy + y] * weights[x][y];
                        temp += picture.pixels[current_posy + y][current_posx + x] * weights[y][x].w;
                        filters++;

                    }
                }
            }

            return temp / filters;

        }
        public void downSample()
        {

            for (int e = 0; e < filter_InputImages.Count(); e++)
            {
                //neues Bild
                Image_Data result = new Image_Data();
                result.belongsToInputImage = filter_InputImages[e];
                //selbe Maße
                result.height = (filter_InputImages[e].height / height);
                result.width = (filter_InputImages[e].width / width);
                //result.pixels.clear();


                for (int i = 0; i <= filter_InputImages[e].height;)
                {
                    List<double> temp = new List<double>();
                    for (int a = 0; a <= filter_InputImages[e].width;)
                    {
                        //DEBUG
                        //result.pixels[i][a]=compareFilter(e,i,a);
                        double tempe = down(e, a, i);

                        temp.Add(tempe);
                        a += width;
                    }
                    result.pixels.Add(temp);
                    i += height;
                }
                filter_OutputImages[e] = (result);
                //        cout<<filter_OutputImages.size()<<endl;



            }
            Net.downSamplingSizeX = filter_OutputImages[0].width;
            Net.downSamplingSizeY = filter_OutputImages[0].height;
        }


        public void loadFilter(int h, int w, string file)
        {
            height = h;
            width = w;

            Bitmap test = null;
            using (var image = new Bitmap(file))
            {
                test = new Bitmap(image);
            }


            for (int a = 0; a < test.Height; a++)
            {
                List<Weight> temp = new List<Weight>();
                temp.Clear();
                for (int b = 0; b < test.Width; b++)
                {

                    Weight we = new Weight();
                    we.w= (Image_Data.ToGrayScale(test.GetPixel(b, a)));

                    temp.Add(we);


                }
                weights.Add(temp);
            }




        }

        public void pooling(int ID)
        {
            Parallel.For(0, filter_InputImages.Length, e =>
          {

              if (filter_InputImages[e] != null)
              {
                  //neues Bild
                  Image_Data result = new Image_Data();
                  result.belongsToInputImage = filter_InputImages[e];
                  //selbe Maße
                  result.height = (filter_InputImages[e].height - height) + 1;
                  result.width = (filter_InputImages[e].width - width) + 1;
                  //result.pixels.clear();

                  for (int i = 0; i < result.height; i++)
                  {
                      List<double> temp = new List<double>();
                      for (int a = 0; a < result.width; a++)
                      {
                          //DEBUG
                          //result.pixels[i][a]=compareFilter(e,i,a);
                          double tempe = pool(e, a, i, ID);

                          temp.Add(tempe);

                      }
                      result.pixels.Add(temp);
                  }
                  filter_OutputImages[e] = (result);
                  //        cout<<filter_OutputImages.size()<<endl;
              }
          });
            Console.WriteLine(width + "|" + height + " : " + filter_OutputImages.Length);
        }


        public double TRANSFER(double val)
        {
            if (val < 0)
                return 0;
            else
                return val;
        }

        public double down(int e, int a, int i)
        {
            Image_Data picture = filter_InputImages[e];

            double temp = 0;

            int current_posy = i;
            int current_posx = a;


            int filters = height * width;


            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                    {
                        // temp += picture.pixels[current_posx + x][current_posy + y];
                        temp += picture.pixels[current_posy + y][current_posx + x];


                    }
                }

            }
            return temp / filters;
        }


        public double pool(int e, int a, int i, int ID)
        {
            Image_Data picture = filter_InputImages[e];
            double temp = 0;

            int topLeftCornery = 0;
            int topLeftCornerx = 0;

            int bottomRightCornery = 0;
            int bottomRightCornerx = 0;


            topLeftCornery = i - ((height - 1) / 2);
            topLeftCornerx = a - ((width - 1) / 2);


            bottomRightCornery = i + ((height - 1) / 2);
            bottomRightCornerx = a + ((width - 1) / 2);


            int current_posx = topLeftCornerx;
            int current_posy = topLeftCornery;

            int filters = 0;

            if (ID == 0)
            {            //average pooling

                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                        {
                            // temp += picture.pixels[current_posx + x][current_posy + y];
                            temp += picture.pixels[current_posy + y][current_posx + x];
                            filters++;

                        }
                    }
                }

                return temp / filters;
            }
            else if (ID == 1)
            {      //max pooling
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (current_posy + y >= 0 && current_posx + x >= 0 && current_posy + y < picture.height && current_posx + x < picture.width)
                        {
                            if (picture.pixels[current_posy + y][current_posx + x] > temp)
                            {
                                temp = picture.pixels[current_posy + y][current_posx + x];
                            }
                        }
                    }
                }
            }
            return temp;
        }


        public void getRandom(int heigh, int widt)
        {

            height = heigh;
            width = widt;


            weights.Clear();
            for (int i = 0; i < height; i++)
            {
                List<Weight> tempVector = new List<Weight>();
                for (int a = 0; a < width; a++)
                {
                    /* double temp;
                     temp = Program.random.NextDouble() * 2.0;
                     temp -= 0.5;*/

                    double rand = new double();
                    rand = (Program.random.Next(0, 100000));
                    rand -= 50000.0;
                    Weight w = new Weight();
                    w.w= rand / 50000.0;


                    tempVector.Add(w);
                }

                weights.Add(tempVector);

            }
        }
    }
}
