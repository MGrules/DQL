﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace DQL
{
    class Net
    {
        //public:
        public string filename;
        public int type;

        public List<ConvLayer> convLayer = new List<ConvLayer>();
        public List<FFLayer> FFLayer = new List<DQL.FFLayer>();
        public List<int> structureVector = new List<int>();
        public List<List<List<int>>> filterSize = new List<List<List<int>>>();
        public List<Image_Data> inputImages = new List<Image_Data>();
        public int numberOfFilter;
        public List<double> inputValues = new List<double>();
        //protected
        public List<double> Net_raw = new List<double>();

        //private

        //Funktionen
        public Net()
        {

        }


        public void generateStructure()
        {
            List<int> structure = new List<int>();

            if (type == 0)
            {

                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
                {
                    structure.Add(Program.FILTER_PER_LAYER[i]);
                    numberOfFilter += Program.FILTER_PER_LAYER[i];

                }
                structureVector = structure;



                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
                {             //1
                    List<List<int>> templayer = new List<List<int>>();
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {             //2
                        List<int> tempfilter = new List<int>();
                        for (int b = 0; b < 2; b++)
                        {
                            tempfilter.Add(Program.DIMENSION_OF_FILTER_IN_LAYER_X[i]);
                            tempfilter.Add(Program.DIMENSION_OF_FILTER_IN_LAYER_Y[i]);
                        }
                        templayer.Add(tempfilter);
                    }
                    filterSize.Add(templayer);
                }

            }
            else if (type == 1)
            {

                for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_FF_NET; i++)
                {
                    structure.Add(Program.NEURONS_PER_LAYER[i]);
                }
                structureVector = structure;

            }
        }


        public void CreateConvNet(bool load, List<int> structureVector)
        {
            if (load)
            {
                Load();
            }
            else
            {
                makeConvNet();
                return;
            }
        }


        public void Load()
        {
            getStructure();
            getNetData();
        }


        public void Save()
        {
            FileStream f = new FileStream("test.nn", FileMode.Create);
            BinaryWriter bw = new BinaryWriter(f);

            //---------------------------------------------------------------------------------HEADER
            int cl = 11;

            cl += Program.NUMBER_OF_LAYERS_IN_CONV_NET * 2; //2 bytes per layer
            cl += Program.NUMBER_OF_LAYERS_IN_FF_NET * 2;


            write_to_bin_stream(bw, cl, 2);


            write_to_bin_stream(bw, 0, 4);


            write_to_bin_stream(bw, Program.NUMBER_OF_LAYERS_IN_CONV_NET, 2);

            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                write_to_bin_stream(bw, Program.FILTER_PER_LAYER[i], 2);
            }

            write_to_bin_stream(bw, Program.NUMBER_OF_LAYERS_IN_FF_NET, 2);

            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_FF_NET; i++)
            {
                write_to_bin_stream(bw, Program.NEURONS_PER_LAYER[i], 2);

            }

            //---------------------------------------------------------------------------------/HEADER



            //---------------------------------------------------------------------------------CONV HEADER

            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                write_to_bin_stream(bw, Program.DIMENSION_OF_FILTER_IN_LAYER_X[i], 2);
                write_to_bin_stream(bw, Program.DIMENSION_OF_FILTER_IN_LAYER_Y[i], 2);
            }

            //---------------------------------------------------------------------------------/CONV HEADER

            for (int a = 0; a < convLayer.Count; a++)
            {

                for (int b = 0; b < convLayer[a].filter.Count; b++)
                {

                    for (int c = 0; c < convLayer[a].filter[b].weights.Count; c++)
                    {

                        for (int d = 0; d < convLayer[a].filter[b].weights[c].Count; d++)
                        {


                            // write_to_bin_stream(&f,convLayer[a].filter[b].weights[c][d],8);
                            bw.Write(convLayer[a].filter[b].weights[c][d] + ";");
                            bw.Flush();
                            //   double temp=convLayer[a].filter[b].weights[c][d];
                            //   f.write(reinterpret_cast<char*>(&temp),sizeof temp);

                        }

                    }

                }


            }

            f.Close();
        }


        public void Show()
        {

            if (type == 0)
            {
                for (int a = 0; a < convLayer.Count; a++)
                {
                    Console.WriteLine();
                    Console.WriteLine("layer number: " + a);

                    for (int b = 0; b < convLayer[a].filter.Count; b++)
                    {
                        Console.WriteLine();
                        for (int c = 0; c < convLayer[a].filter[b].weights.Count; c++)
                        {
                            Console.WriteLine();
                            for (int d = 0; d < convLayer[a].filter[b].weights[c].Count; d++)
                            {
                                //cout<<endl;
                                Console.Write(convLayer[a].filter[b].weights[c][d] + ";");


                            }

                        }

                    }


                }
            }
            else if (type == 1)
            {

                for (int a = 0; a < Program.NUMBER_OF_LAYERS_IN_FF_NET; a++)
                {

                    Console.WriteLine();
                    Console.WriteLine("FF layer number: " + a);

                    for (int b = 0; b < Program.NEURONS_PER_LAYER[a]; b++)
                    {
                        Console.WriteLine();
                        for (int c = 0; c < FFLayer[a].neurons[b].weightsToNextNeurons.Count; c++)
                        {

                            Console.WriteLine(FFLayer[a].neurons[b].weightsToNextNeurons[c]);
                        }
                        Console.WriteLine();
                    }


                }


            }
        }


        public void getImage(Bitmap bitmap)
        {
            Image_Data img = new Image_Data(bitmap);
            Console.WriteLine(bitmap.Width + "|" + bitmap.Height);
            inputImages.Clear();
            inputImages.Add(img);
        }


        public void passThroughFF()
        {
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_FF_NET; i++)
            {
                if (i == 0)
                {
                    for (int x = 0; x < FFLayer[0].neurons.Count; x++)
                    {
                        FFLayer[0].neurons[x].inputValues.Clear();
                        for (int y = 0; y < inputValues.Count; y++)
                        {
                            FFLayer[0].neurons[x].inputValues.Add(inputValues[y]);
                        }
                    }
                    continue;
                }


                if (i < Program.NUMBER_OF_LAYERS_IN_FF_NET - 1)
                {


                    for (int a = 0; a < Program.NEURONS_PER_LAYER[i]; a++)
                    {

                        for (int b = 0; b < Program.NEURONS_PER_LAYER[i + 1]; b++)
                        {
                            if (i < Program.NUMBER_OF_LAYERS_IN_FF_NET - 1)
                            {



                                FFLayer[i + 1].neurons[b].inputValues.Add(FFLayer[i].neurons[a].weightsToNextNeurons[b] * FFLayer[i].neurons[a].outputValue);
                            }
                        }
                        for (int z = 0; z < FFLayer[i + 1].neurons.Count; z++)
                        {
                            FFLayer[i + 1].neurons[z].calculateSum();
                        }


                        FFLayer[i].freeMemory();
                    }


                }

            }
        }

        public void passThroughConv()
        {
            Console.WriteLine("\t" + inputImages.Count + "\t" + Program.NUMBER_OF_LAYERS_IN_CONV_NET);
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET; i++)
            {
                Console.WriteLine("Currently in Layer " + i + " of " + Program.NUMBER_OF_LAYERS_IN_CONV_NET + " the conv; Layer ID = "+Program.LAYER_ID[i]);
                
                //        cout<<"-----------------------------------------"<<endl
                if (i == 0)
                {

                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < inputImages.Count; b++)
                        {
                            convLayer[i].filter[a].filter_InputImages.Add(inputImages[b]);

                        }
                        switch (Program.LAYER_ID[0])
                        {
                            case 0: convLayer[i].filter[a].pooling(Program.POOLING_ID[0]); break;
                            case 1: convLayer[i].filter[a].useFilter(); break;
                            case 2: convLayer[i].filter[a].RLU(); break;
                            case 3: convLayer[i].filter[a].downSample(); break;
                        }

                        
                    }
                    convLayer[i].freeMemory();
                    continue;

                }

                if (Program.LAYER_ID[i] == 0)       //pooling
                {

                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            for (int c = 0; c < convLayer[i - 1].filter[b].filter_OutputImages.Count; c++)
                            {
                                convLayer[i].filter[a].filter_InputImages.Add(convLayer[i - 1].filter[b].filter_OutputImages[c]);
                            }
                        }
                        convLayer[i].filter[a].pooling(Program.POOLING_ID[i]);
                    }
                    convLayer[i].freeMemory();
                }
                else if (Program.LAYER_ID[i] == 1)
                {
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            for (int c = 0; c < convLayer[i - 1].filter[b].filter_OutputImages.Count; c++)
                            {
                                convLayer[i].filter[a].filter_InputImages.Add(convLayer[i - 1].filter[b].filter_OutputImages[c]);

                            }
                        }
                        convLayer[i].filter[a].useFilter();
                    }
                    convLayer[i].freeMemory();

                }
                else if (Program.LAYER_ID[i] == 2)
                {
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            for (int c = 0; c < convLayer[i - 1].filter[b].filter_OutputImages.Count; c++)
                            {
                                convLayer[i].filter[a].filter_InputImages.Add(convLayer[i - 1].filter[b].filter_OutputImages[c]);

                            }
                        }
                        convLayer[i].filter[a].RLU();
                    }
                    convLayer[i].freeMemory();
                }
                else if(Program.LAYER_ID[i]==3)
                {
                   
                    for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                    {
                        for (int b = 0; b < Program.FILTER_PER_LAYER[i - 1]; b++)
                        {
                            for (int c = 0; c < convLayer[i - 1].filter[b].filter_OutputImages.Count; c++)
                            {
                                convLayer[i].filter[a].filter_InputImages.Add(convLayer[i - 1].filter[b].filter_OutputImages[c]);

                            }
                        }
                        
                        convLayer[i].filter[a].downSample();
                    }
                    convLayer[i].freeMemory();
                }
            }
            for (int i = 0; i < Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1; i++)
            {
                for (int a = 0; a < Program.FILTER_PER_LAYER[i]; a++)
                {
                    convLayer[i].filter[a].filter_InputImages.Clear();
                    convLayer[i].filter[a].filter_OutputImages.Clear();
                }
            }
            
        }


        public void CreateFFNet(bool load, List<int> structureVector)
        {
            if (load)
            {
                Load();
            }
            else
            {
                makeFFNet();
                return;
            }


        }

        public int showResult()
        {
            if (type == 0)
            {
                //  Console.WriteLine(convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[0].filter_OutputImages.Count);

                for (int i = 0; i < convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter.Count; i++)
                {
                    for (int a = 0; a < convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages.Count; a++)
                    {
                        //convLayer[Program.NUMBER_OF_LAYERS_IN_CONV_NET - 1].filter[i].filter_OutputImages[a].showImage();
                    }
                }
                Console.WriteLine();
                return -1;
            } else if (type == 1)
            {
                // Console.WriteLine(FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET-1].neurons[])
                int max = 0;
                double highestVal = -1;
                for (int a = 0; a < Program.NEURONS_PER_LAYER[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1]; a++)
                {
                    if(FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue > highestVal)
                    {
                        max = a;
                        highestVal = FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue;
                    }
                    
                    Console.WriteLine(FFLayer[Program.NUMBER_OF_LAYERS_IN_FF_NET - 1].neurons[a].outputValue);
                }

                return max;
            }
            return -1;

        }
    

       
        //protected:


        //private:
        private void write_to_bin_stream(BinaryWriter f, int number, int length)
        {
            if (f != null)
            {
                for (int i = 0; i < length; i++)
                {
                    f.Write(int_to_hex(number, length)[i]);
                    f.Flush();
                }

            }
            else Console.WriteLine("error");

        }


        private string int_to_hex(int i, int l)
        {
            string temp = "";
            for (int a = 0; a < l; a++)
            {
                temp += i;
                i >>= 8;
            }
            return temp;
        }


        private void makeFFNet()
        {
            for (int a = 0; a < Program.NUMBER_OF_LAYERS_IN_FF_NET; a++)
            {
               
                FFLayer tempLayer = new FFLayer();
                
                tempLayer.neurons.Clear();
                for(int b = 0; b < Program.NEURONS_PER_LAYER[a]; b++)
                {
                    FFNeuron tempNeuron = new FFNeuron();
                    if (a < Program.NUMBER_OF_LAYERS_IN_FF_NET-1)
                    {
                        
                        tempNeuron.getRandom(Program.NEURONS_PER_LAYER[a+1]);
                        tempLayer.neurons.Add(tempNeuron);
                        
                    }
                    else
                    {
                        tempLayer.neurons.Add(tempNeuron);
                    }
                    
                    
                }
                FFLayer.Add(tempLayer);

            }


        }


        private void makeConvNet()
        {
            for (int a = 0; a < structureVector.Count; a++)
            {

                ConvLayer tempLayer = new ConvLayer();
                Filter tempFilter = new Filter();
                tempLayer.filter.Clear();
                for (int b = 0; b < structureVector[a]; b++)
                {



                    tempFilter.weights.Clear();



                    tempFilter.getRandom(filterSize[a][b][0], filterSize[a][b][1]);
                    tempLayer.filter.Add(tempFilter);


                }
                convLayer.Add(tempLayer);

            }


            Console.WriteLine("Done making new net ");
            return;
        }

        private int getStructure()
        {
            FileStream stream = new FileStream(filename, FileMode.Open);
            BinaryReader f = new BinaryReader(stream);

            int numberOfLayers;

            if (stream == null)
            {
                Console.WriteLine("error loading file " + filename);
                return -1;
            }

            List<char> fileCHAR = new List<char>();
            char current = f.ReadChar();
            while(current != '\0')
            {
                fileCHAR.Add(current);
                current = f.ReadChar();
            }

            numberOfLayers = CalculateBytes(fileCHAR, Program.NUMBER_OF_LAYERS_OFFSET, Program.NUMBER_OF_LAYERS_OFFSET + 1);

            for (int a = 1; a <= numberOfLayers; a++)
            {
                structureVector.Add(CalculateBytes(fileCHAR, Program.FIRST_LAYER_OFFSET + 2 * a, (Program.FIRST_LAYER_OFFSET + 2 * a + 1)));
            }

            return 0;
        }


        private int getNetData()
        {
            FileStream stream = new FileStream(filename, FileMode.Open);
            BinaryReader f = new BinaryReader(stream);

            if (stream == null)
            {
                Console.WriteLine( "error loading file " + filename );
                return -1;
            }

            List<char> fileCHAR = new List<char>();
            char current = f.ReadChar();
            while (current != '\0')
            {
                fileCHAR.Add(current);
                current = f.ReadChar();
            }


            return 0;

        }

        private int CalculateBytes(List<char> v, int start, int finish)
        {
            int result = 0;


            for (int a = start; a <= finish; a++)
            {

                result += (int)Math.Pow(16.0, 2.0 * (a - start)) * v[a];

            }

            return result;

        }

    }
}
