﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;

namespace DQL
{
    class Interaction
    {
        [DllImport("user32.dll")]
        public static extern int SetForegroundWindow(IntPtr hWnd);

        private const int MOUSEEVENTF_MOVE = 0x0001; /* mouse move */
        private const int MOUSEEVENTF_LEFTDOWN = 0x0002; /* left button down */
        private const int MOUSEEVENTF_LEFTUP = 0x0004; /* left button up */
        private const int MOUSEEVENTF_RIGHTDOWN = 0x0008; /* right button down */

        [DllImport("user32.dll",
            CharSet = CharSet.Auto, CallingConvention= CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons,
                                              int dwExtraInfo);

        void RegularClick()
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        }
        void RegularStartUp(Process process)
        {
            SetForegroundWindow(process.MainWindowHandle);

            Cursor.Position = new System.Drawing.Point(480, 550);

            Thread.Sleep(10000);
            Console.WriteLine("Click!");
            RegularClick();
            Thread.Sleep(1000);
            RegularClick();
        }
        Bitmap TakeScreenshot()
        {
            Bitmap screen = new Bitmap(SystemInformation.VirtualScreen.Width - 970, SystemInformation.VirtualScreen.Height - 535);
            Graphics g = Graphics.FromImage(screen);
            g.CopyFromScreen(10,285, 0,0, screen.Size);
            g.Dispose();
            /*
            for(int a = 0; a < screen.Height; a++)
            {
                for (int b = 0; b < screen.Width; b++)
                {
                    Color p = screen.GetPixel(b, a);
                    Console.Write("(" + p.R + "|" + p.G + "|" + p.B + ") , ");
                }
                Console.WriteLine();
            }
            */
            return screen;
        }
        public Interaction()
        {
            
        }
        [STAThread]
        public void Interact()
        {
            
            Process process = Process.Start("firefox", "pong-2.com");
            process.WaitForInputIdle();


            RegularStartUp(process);
            Process[] processes = Process.GetProcessesByName("firefox");
            if (processes.Length == 0) return;

            process = processes[0];
            SetForegroundWindow(process.MainWindowHandle);
            Stopwatch actionTimer = new Stopwatch();
            while (process != null)
            {
                SetForegroundWindow(process.MainWindowHandle);
                Program.convNet.getImage(TakeScreenshot());
                Program.PassThrough();
                int result = Program.FFNet.showResult();
                if (result == 0)
                {
                    SendKeys.SendWait("{DOWN}");
                }
                else
                {
                    SendKeys.SendWait("{UP}");
                }

                Console.WriteLine(result);

                Thread.Sleep(5);
                processes = Process.GetProcessesByName("firefox");
                if (processes.Length == 0)
                    break;
                process = processes[0];
            }
        }
    }
}
